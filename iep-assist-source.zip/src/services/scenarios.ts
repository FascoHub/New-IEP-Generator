import { Condition, IEPDocument, LearnerData } from '../types';
import { emptyLearner } from './validation';

// All learners below are FICTIONAL. Do not replace with real learner data.

export interface Scenario {
  id: string;
  title: string;
  purpose: string;
  data: LearnerData;
  expect: (iep: IEPDocument) => { label: string; pass: boolean }[];
}

const mk = (o: Partial<LearnerData> & { diagnosis: Condition[] }): LearnerData => ({ ...emptyLearner(), ...o });
const keys = (i: IEPDocument) => i.goals.map((g) => g.areaKey);
const inDomain = (i: IEPDocument, d: string) => i.goals.filter((g) => g.domain === d).length;
const allText = (i: IEPDocument) => JSON.stringify([i.goals, i.accommodations, i.strategies, i.needs]).toLowerCase();

export const SCENARIOS: Scenario[] = [
  {
    id: 's1', title: '1. ADHD — task initiation and completion',
    purpose: 'Functional goals are generated from documented task-management evidence. Reading and mathematics are at grade level, so no goals appear there. Peer interaction is a documented strength and is not labelled as a problem.',
    data: mk({
      learnerName: 'Tobi Adeleke', grade: 'Primary 4', age: '9', diagnosis: ['ADHD'],
      readingLevel: 'At Grade Level', readingObservation: 'Reads grade-level texts fluently and answers questions accurately.',
      mathLevel: 'At Grade Level', mathObservation: 'Shows strong mathematical reasoning and enjoys puzzles.',
      behaviourSocial: 'Has difficulty starting independent tasks and needs several reminders to begin. Often leaves written tasks unfinished, and needs prompts to complete the last steps. Works well in pairs and has good peer interaction. Follows routines when a visual timetable is displayed.',
      parentConcerns: 'Parents say homework takes a long time to start each evening.',
      learnerStrengths: 'Strong mathematical reasoning. Enjoys science experiments. Friendly and well liked by classmates. Creative ideas in class discussions.',
    }),
    expect: (i) => [
      { label: 'Goals for task initiation and task completion', pass: keys(i).includes('taskInitiation') && keys(i).includes('taskCompletion') },
      { label: 'No reading goal and no mathematics goal', pass: inDomain(i, 'reading') === 0 && inDomain(i, 'mathematics') === 0 },
      { label: 'No peer-interaction need created (documented strength)', pass: !i.needs.some((n) => n.areaKey === 'peerInteraction') },
      { label: 'No “disruptive” labelling anywhere', pass: !allText(i).includes('disruptive') },
      { label: 'Every goal without a numeric baseline says baseline data required', pass: i.goals.every((g) => g.baseline.includes('[Baseline data required]')) },
    ],
  },
  {
    id: 's2', title: '2. Dyslexia — decoding and fluency, mathematics at grade level',
    purpose: 'Reading goals come from documented decoding and fluency evidence. No mathematics goal is created. A teacher-reported figure is reused as a baseline; none is invented.',
    data: mk({
      learnerName: 'Amaka Eze', grade: 'Primary 3', age: '8', diagnosis: ['Dyslexia'],
      readingLevel: 'Below Grade Level',
      readingObservation: 'Finds it hard to sound out unfamiliar words and often guesses from the first letter. Reads slowly, word by word, and loses the meaning of longer sentences. Understands stories well when they are read aloud to her. Asked to read a passage aloud, she read 24 words correctly in one minute.',
      mathLevel: 'At Grade Level', mathObservation: 'Confident with addition and subtraction within 100 and uses number lines independently.',
      behaviourSocial: 'Participates willingly in oral discussions and is patient with peers. Becomes discouraged during silent reading time.',
      parentConcerns: 'Parents would like her to read simple bedtime stories with confidence.',
      learnerStrengths: 'Strong oral communication. Enjoys science and asking questions. Good memory for facts and stories.',
    }),
    expect: (i) => [
      { label: 'Reading goals for decoding and fluency', pass: keys(i).includes('decoding') && keys(i).includes('fluency') },
      { label: 'No mathematics goal', pass: inDomain(i, 'mathematics') === 0 },
      { label: 'Fluency goal uses the teacher-reported baseline (24 words)', pass: !!i.goals.find((g) => g.areaKey === 'fluency')?.baseline.includes('24 words') },
      { label: 'Decoding goal has no invented baseline', pass: !!i.goals.find((g) => g.areaKey === 'decoding')?.baseline.includes('[Baseline data required]') },
      { label: 'Oral strength used in a strategy', pass: i.strategies.some((s) => s.areaLabels.includes('Learner strengths')) },
    ],
  },
  {
    id: 's3', title: '3. Dyscalculia — number sense and calculation, reading at grade level',
    purpose: 'Mathematics goals come from documented number-sense and calculation evidence. No reading goal is created.',
    data: mk({
      learnerName: 'Musa Bello', grade: 'Primary 5', age: '10', diagnosis: ['Dyscalculia'],
      readingLevel: 'At Grade Level', readingObservation: 'Reads grade-level texts accurately and explains what happened in a story in his own words.',
      mathLevel: 'Below Grade Level',
      mathObservation: 'Cannot reliably say which of two numbers is larger without counting objects. Makes frequent errors when adding and subtracting with regrouping and often forgets number facts he practised the day before. Uses counters and a number line successfully.',
      behaviourSocial: 'Works carefully and asks for help politely. Prefers untimed tasks.',
      parentConcerns: 'Parents are concerned about homework time.',
      learnerStrengths: 'Strong verbal reasoning. Enjoys building models and drawing. Persistent when tasks are hands-on.',
    }),
    expect: (i) => [
      { label: 'Mathematics goals for number sense and calculation', pass: keys(i).includes('numberSense') && keys(i).includes('calculation') },
      { label: 'No reading goal', pass: inDomain(i, 'reading') === 0 },
      { label: 'No counting goal (counting is not evidenced as a difficulty)', pass: !keys(i).includes('counting') },
      { label: 'Concrete materials recommended', pass: i.accommodations.some((a) => /concrete|manipulative|counters/i.test(a.text)) },
    ],
  },
  {
    id: 's4', title: '4. Dysgraphia — handwriting and written expression',
    purpose: 'Writing goals come from the writing observation. Reading and mathematics remain at grade level with no goals. A typing strength is used in a strategy.',
    data: mk({
      learnerName: 'Ngozi Okoro', grade: 'Primary 4', age: '9', diagnosis: ['Dysgraphia'],
      readingLevel: 'At Grade Level', readingObservation: 'Reads confidently and enjoys reading aloud.',
      writingObservation: 'Letters are often uneven in size and hard to read, and she forms several letters from the bottom up. Copying from the board is slow and she often misses lines. Her spoken ideas are detailed, but her written responses are limited to one or two short sentences. She has difficulty organising her ideas into written sentences. She writes more when typing.',
      mathLevel: 'At Grade Level', mathObservation: 'Solves problems mentally and explains her thinking clearly.',
      behaviourSocial: 'Tires quickly during extended writing tasks and sometimes puts her pencil down. Participates actively in class discussions and works well with others.',
      parentConcerns: '',
      learnerStrengths: 'Detailed spoken ideas. Enjoys typing on a keyboard. Creative storyteller. Reads confidently.',
    }),
    expect: (i) => [
      { label: 'Writing goals for handwriting/copying and written expression', pass: keys(i).includes('transcription') && keys(i).includes('writtenExpression') },
      { label: 'No reading goal and no mathematics goal', pass: inDomain(i, 'reading') === 0 && inDomain(i, 'mathematics') === 0 },
      { label: 'Alternative recording methods recommended', pass: i.accommodations.some((a) => /typed|spoken|scribed/i.test(a.text)) },
      { label: 'Parent concerns stated as not provided', pass: i.missing.some((m) => m.message === 'Parent/carer concerns were not provided.') },
    ],
  },
  {
    id: 's5', title: '5. Multiple/Co-occurring — ADHD + Dyslexia',
    purpose: 'Evidence from several domains is integrated. Overlapping and distinct needs are separated, duplicate recommendations are merged and the number of goals is capped.',
    data: mk({
      learnerName: 'Folake Balogun', grade: 'Primary 5', age: '10', diagnosis: ['ADHD', 'Dyslexia'], coOccurring: true,
      readingLevel: 'Approaching Grade Level',
      readingObservation: 'Decoding is accurate for familiar words, but she struggles with multi-syllable words and reads slowly in longer passages. Spelling of taught words is often inconsistent in dictation. Understands short texts well when key words are explained first. Retelling a longer story in order is difficult, and she loses focus part-way through.',
      mathLevel: 'At Grade Level', mathObservation: 'Calculates accurately when given time and a checklist of steps.',
      behaviourSocial: 'Needs frequent reminders to begin independent written work and often loses track of the task partway through. Distracted by noise from the corridor. Cheerful and helpful with classmates.',
      parentConcerns: 'Parents worry that she is falling behind in reading and finds homework overwhelming.',
      learnerStrengths: 'Creative thinker. Strong oral storytelling. Kind and helpful. Enjoys drawing and art.',
    }),
    expect: (i) => [
      { label: 'Goals from reading, writing and functional domains', pass: inDomain(i, 'reading') > 0 && inDomain(i, 'writing') > 0 && inDomain(i, 'functional') > 0 },
      { label: 'No mathematics goal', pass: inDomain(i, 'mathematics') === 0 },
      { label: 'No more than five goals', pass: i.goals.length <= 5 && i.goals.length > 0 },
      { label: 'Overlapping and distinct needs are described', pass: i.overlapSummary.length >= 2 && i.needs.some((n) => n.overlap === 'overlapping') },
      { label: 'No duplicate accommodation text', pass: new Set(i.accommodations.map((a) => a.text)).size === i.accommodations.length },
    ],
  },
  {
    id: 's6', title: '6. Insufficient information — Dyscalculia selected, little supplied',
    purpose: 'Only a diagnosis and a brief strength are supplied. The system must flag missing information and generate no goals, rather than invent needs from the diagnosis.',
    data: mk({
      learnerName: 'Emeka Nwosu', grade: 'Primary 2', age: '7', diagnosis: ['Dyscalculia'],
      readingLevel: 'Not Assessed', mathLevel: 'Not Assessed', learnerStrengths: 'Friendly and curious.',
    }),
    expect: (i) => [
      { label: 'No goals generated', pass: i.goals.length === 0 },
      { label: 'No needs invented', pass: i.needs.length === 0 },
      { label: 'Not-assessed items flagged for reading and mathematics', pass: i.missing.filter((m) => m.kind === 'not_assessed').length === 2 },
      { label: 'Teacher observation recommended for mathematics', pass: i.missing.some((m) => m.kind === 'observation_recommended' && m.area === 'Mathematics') },
      { label: 'No-goal message shown', pass: i.noGoalMessages.length >= 2 && i.noGoalMessages.every((m) => m.message.includes('No measurable goal was generated')) },
    ],
  },
  {
    id: 's7', title: '7. Same diagnosis, different evidence — Dyslexia (spelling only)',
    purpose: 'Contrast with scenario 2. This learner also has Dyslexia, but the teacher documents accurate decoding and fluency and a spelling difficulty. The output differs completely.',
    data: mk({
      learnerName: 'Kelechi Obi', grade: 'Primary 3', age: '8', diagnosis: ['Dyslexia'],
      readingLevel: 'At Grade Level', readingObservation: 'Decodes unfamiliar words accurately and reads at a comfortable pace.',
      writingObservation: 'Spells many taught words incorrectly in independent writing, although reading is accurate.',
      mathLevel: 'Above Grade Level', mathObservation: 'Confident with problem-solving and enjoys number puzzles.',
      behaviourSocial: 'Works well in groups and is confident when speaking.',
      parentConcerns: 'Parents would like more support with spelling homework.',
      learnerStrengths: 'Confident reader. Enjoys number puzzles. Good at explaining ideas aloud.',
    }),
    expect: (i) => [
      { label: 'Spelling goal generated', pass: keys(i).includes('spelling') },
      { label: 'No reading goal despite Dyslexia', pass: inDomain(i, 'reading') === 0 },
      { label: 'No mathematics goal', pass: inDomain(i, 'mathematics') === 0 },
      { label: 'Goal set differs from scenario 2', pass: !keys(i).includes('decoding') && !keys(i).includes('fluency') },
    ],
  },
];
