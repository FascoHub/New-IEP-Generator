import { AppSettings, AuditEvent, IEPDocument } from '../types';
import { APP_NAME, DEFAULT_REVIEW_PERIOD, DEFAULT_THEME } from './referenceData';
import { generateIEP } from './iepGenerator';
import { SCENARIOS } from './scenarios';

// Mock persistence. Every read and write is guarded because browser storage can be unavailable
// (private mode, embedded viewers). The app still works in memory if storage fails.
// PRODUCTION NOTE: replace with an authenticated, encrypted server-side store with audit logging.
const K = { records: 'iepassist.v1.records', audit: 'iepassist.v1.audit', settings: 'iepassist.v1.settings', session: 'iepassist.v1.session' };

function read<T>(key: string, fallback: T): T {
  try { const v = window.localStorage.getItem(key); return v ? (JSON.parse(v) as T) : fallback; } catch { return fallback; }
}
function write(key: string, value: unknown): void {
  try { window.localStorage.setItem(key, JSON.stringify(value)); } catch { /* storage unavailable: keep working in memory */ }
}
export function clearAll(): void {
  try { Object.values(K).forEach((k) => window.localStorage.removeItem(k)); } catch { /* ignore */ }
}

export const loadRecords = (): IEPDocument[] | null => read<IEPDocument[] | null>(K.records, null);
export const saveRecords = (r: IEPDocument[]) => write(K.records, r);
export const loadAudit = (): AuditEvent[] => read<AuditEvent[]>(K.audit, []);
export const saveAudit = (a: AuditEvent[]) => write(K.audit, a.slice(0, 200));
export const loadSettings = (): AppSettings => {
  const saved = read<Partial<AppSettings>>(K.settings, {});
  return { revealNames: false, defaultReviewPeriod: DEFAULT_REVIEW_PERIOD, appName: APP_NAME, showHero: true, textSize: 'normal', ...saved, theme: { ...DEFAULT_THEME, ...(saved.theme || {}) } };
};
export const saveSettings = (s: AppSettings) => write(K.settings, s);
export const loadSession = (): { name: string; role: string } | null => read(K.session, null);
export const saveSession = (s: { name: string; role: string } | null) => (s ? write(K.session, s) : (() => { try { window.localStorage.removeItem(K.session); } catch { /* ignore */ } })());

const daysAgo = (n: number) => new Date(Date.now() - n * 86400000).toISOString();

/** Fictional demonstration records only. */
export function seedRecords(): IEPDocument[] {
  const pick = ['s1', 's2', 's3', 's5'];
  const ages = [1, 4, 12, 20];
  return pick.map((id, i) => {
    const sc = SCENARIOS.find((s) => s.id === id)!;
    const doc = generateIEP(sc.data, { sequence: i + 1, createdAt: daysAgo(ages[i] + 3) });
    doc.updatedAt = daysAgo(ages[i]);
    if (id === 's1') doc.status = 'Completed';
    return doc;
  });
}
