import { IEPDocument } from '../types';
import { formatGoal } from './goalQuality';
import { DRAFT_NOTICE } from './referenceData';

export function iepToText(i: IEPDocument): string {
  const L: string[] = [];
  const h = (t: string) => { L.push('', t.toUpperCase(), '='.repeat(t.length)); };
  L.push(`INDIVIDUALISED EDUCATION PLAN (${i.status})`, `Reference: ${i.reference}`, '', `AI-GENERATED DRAFT: ${DRAFT_NOTICE}`);
  h('1. Learner profile');
  L.push(`Learner: ${i.learner.learnerName}`, `Grade/class: ${i.learner.grade}`, `Age: ${i.learner.age}`, `Diagnosis/identified need: ${i.diagnosisNote}`, `Date: ${i.iepDate}`, `IEP status: ${i.status}`, `Review timeline: ${i.reviewPeriod}`);
  h('2. Learner strengths');
  i.strengths.forEach((s) => L.push(`- ${s}`));
  h('3. Present levels of academic and functional performance');
  i.presentLevels.forEach((p) => {
    L.push('', p.title, p.level);
    if (p.statusMessage) L.push(p.statusMessage);
    if (p.strengths.length) L.push('Strengths:', ...p.strengths.map((x) => `  - ${x}`));
    if (p.needs.length) L.push('Documented needs:', ...p.needs.map((x) => `  - ${x}`));
    if (p.observations.length) L.push('Observable information (teacher):', ...p.observations.map((x) => `  - ${x}`));
    if (p.baseline.length) L.push('Baseline information:', ...p.baseline.map((x) => `  - ${x}`));
  });
  h('4. Identified educational needs');
  if (!i.needs.length) L.push('No educational needs were identified from the information supplied.');
  i.needs.forEach((n) => L.push(`- ${n.statement}${n.evidence[0] ? ` Evidence: “${n.evidence[0].text}”` : ''}`));
  h('5. Goals');
  i.goals.forEach((g, k) => L.push('', `Goal ${k + 1} (${g.areaLabel})`, formatGoal(g), `Baseline: ${g.baseline}`, `Why: ${g.why}`));
  i.noGoalMessages.forEach((m) => L.push(m.message));
  h('6. Classroom accommodations');
  i.accommodations.forEach((a) => L.push(`- ${a.text}`, `  Why: ${a.why}`));
  h('7. Teacher strategies');
  i.strategies.forEach((a) => L.push(`- ${a.text}`, `  Why: ${a.why}`));
  h('8. Progress monitoring');
  i.goals.forEach((g) => L.push(`- ${g.areaLabel}: measure ${g.monitoring.measure}; method ${g.monitoring.method}; frequency ${g.monitoring.frequency}; collected by ${g.monitoring.collectedBy}; review ${g.monitoring.reviewPoint}`));
  L.push(`Recommended review timeline: ${i.reviewPeriod} (suggested by IEP Assist; adjust to school policy).`);
  h('9. Missing information');
  i.missing.filter((m) => !m.resolved).forEach((m) => L.push(`- ${m.message}`));
  return L.join('\n');
}
