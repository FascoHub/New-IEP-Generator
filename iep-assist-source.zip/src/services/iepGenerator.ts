import {
  Condition, Domain, EvidenceItem, FieldKey, Goal, IEPDocument, LearnerData, MissingItem, NeedItem,
  PresentLevel, Recommendation, TraceStep,
} from '../types';
import { AREAS, AreaDef, DOMAIN_FIELDS, DOMAIN_TITLES } from './areaCatalogue';
import { BASELINE_PLACEHOLDER } from './goalQuality';
import { FIELD_LABELS, termRegex } from './validation';
import {
  DEFAULT_REVIEW_PERIOD, DEFICIT_TERMS, GENERATOR_VERSION, LABEL_TERMS, NO_GOAL_MESSAGE, TIMEFRAME_DEFAULT,
} from './referenceData';

// ===========================================================================
// MOCK AI GENERATOR — /services/iepGenerator.ts
//
// Pipeline (never skips from diagnosis to goals):
//   input -> validation -> strengths -> needs -> domains -> baselines -> goals
//   -> accommodations -> strategies -> monitoring -> draft
//
// The diagnosis is used ONLY for (a) the profile line, (b) describing overlap for
// co-occurring learners and (c) prompting the teacher to supply missing evidence.
// It never creates a need, a goal, an accommodation or a strategy.
// A real model can replace `generateIEP` by implementing IEPGeneratorService.
// ===========================================================================

export interface GenerateOptions { id?: string; sequence?: number; createdAt?: string; reviewPeriod?: string }
export interface IEPGeneratorService { generate(learner: LearnerData, opts?: GenerateOptions): Promise<IEPDocument> }

type Polarity = 'need' | 'strength' | 'neutral';
interface Clause { field: FieldKey; text: string; polarity: Polarity; excluded: '' | 'deficit' | 'label' }
interface Hit {
  area: AreaDef; index: number; teacherScore: number; parentScore: number;
  needEvidence: EvidenceItem[]; strengthEvidence: EvidenceItem[]; allTeacher: EvidenceItem[];
}

const OBS_FIELDS: FieldKey[] = ['readingObservation', 'writingObservation', 'mathObservation', 'behaviourSocial', 'parentConcerns'];
const DEFICIT_RE = termRegex(DEFICIT_TERMS);
const LABEL_RE = termRegex(LABEL_TERMS);

const HARD_NEED = /\b(struggl\w*|difficult\w*|finds? (it )?(hard|difficult)|hard to|trouble|cannot|can't|unable|confus\w*|fail\w* to)\b/i;
const SOFT_NEED = /\b(slow(ly)?|revers\w*|omit\w*|miss(es|ed|ing)?|avoid\w*|reluctan\w*|rarely|seldom|often (forgets?|loses|leaves|stops)|needs? (frequent |several |repeated )?(reminders?|prompt\w*|support|help)|inconsistent\w*|inaccurate\w*|incorrect\w*|wrong\w*|below|delay\w*|tires?|fatigue\w*|distract\w*|unfinished|incomplete|does(n't| not) (complete|start|finish|begin)|lack\w*|limited|poor(ly)?|weak\w*|errors?|mistakes?|discourag\w*|laborious|halting|guess\w*|stumbl\w*|hesitat\w*|uneven|messy|shorter|loses? (track|focus)|anxious|frustrat\w*|upset|forgets?|overwhelm\w*)\b/i;
const STRENGTH = /\b(strong\w*|strength\w*|good|excellent|confident\w*|enjoys?|loves?|fluent\w*|accurate\w*|able to|creative|curious|eager|motivated|persisten\w*|kind|helpful|articulate|thrives?|responds? well|succe\w+|talent\w*|skilled|comfortabl\w*|well|willing\w*|patient|cheerful|carefully)\b/i;
const NEG_STRENGTH = /\b(not|never|n't|rarely|seldom)\b[^.]{0,20}\b(well|accurate\w*|fluent\w*|confident\w*|able to|successful\w*)\b/i;
const NEGATED_DIFFICULTY = /\b(no|not|never|without|hardly)\b[^.]{0,30}\b(difficult\w*|struggl\w*|problems?|trouble|issues?|concerns?)\b|\b(does|do)(n't| not) struggle\b/i;
const NUMERIC_BASELINE = /\b\d+(\.\d+)?\s*(%|percent|wpm|words?|out of|of\s+\d+|minutes?|mins?|times|trials?|sessions?|reminders?|prompts?|correct)\b|\b\d+\s*\/\s*\d+/i;

// ------------------------------- helpers ---------------------------------
const uid = (p: string) => `${p}_${Math.random().toString(36).slice(2, 8)}`;
const lower = (s: string) => s.charAt(0).toLowerCase() + s.slice(1);
const clean = (s: string) => s.trim().replace(/[.;,\s]+$/, '');
const cap = (s: string) => (s ? s.charAt(0).toUpperCase() + s.slice(1) : s);
const quote = (s: string, n = 170) => `“${clean(s).length > n ? clean(s).slice(0, n - 1) + '…' : clean(s)}”`;

export function splitClauses(text: string): string[] {
  return (text || '')
    .split(/\n+|(?<=[.!?;])\s+|\s+(?:but|however|although|though|whereas)\s+/i)
    .map((s) => s.trim().replace(/^[-•*\d.)\s]+/, '').trim())
    .filter((s) => s.length > 2);
}

export function clausePolarity(c: string): Polarity {
  if (NEGATED_DIFFICULTY.test(c)) return 'strength';
  const hard = HARD_NEED.test(c);
  const soft = SOFT_NEED.test(c);
  const str = STRENGTH.test(c);
  if (NEG_STRENGTH.test(c) || hard) return 'need';
  if (soft) return 'need';
  if (str) return 'strength';
  return 'neutral';
}

function extractClauses(d: LearnerData): Clause[] {
  const out: Clause[] = [];
  for (const field of OBS_FIELDS) {
    for (const text of splitClauses(d[field])) {
      const excluded = DEFICIT_RE.test(text) ? 'deficit' : LABEL_RE.test(text) ? 'label' : '';
      out.push({ field, text, polarity: clausePolarity(text), excluded });
    }
  }
  return out;
}

const ev = (c: Clause): EvidenceItem => ({ field: c.field, fieldLabel: FIELD_LABELS[c.field], text: clean(c.text) });
const primaryField: Record<Domain, FieldKey> = {
  reading: 'readingObservation', mathematics: 'mathObservation', writing: 'writingObservation', functional: 'behaviourSocial',
};
const DOMAIN_ORDER: Domain[] = ['reading', 'mathematics', 'writing', 'functional'];

function analyse(d: LearnerData, clauses: Clause[]): Hit[] {
  const hits: Hit[] = [];
  AREAS.forEach((area, index) => {
    const hit: Hit = { area, index, teacherScore: 0, parentScore: 0, needEvidence: [], strengthEvidence: [], allTeacher: [] };
    const allowed = DOMAIN_FIELDS[area.domain];
    for (const c of clauses) {
      if (c.excluded || !allowed.includes(c.field) || !area.cues.test(c.text)) continue;
      const teacher = c.field !== 'parentConcerns';
      if (teacher) hit.allTeacher.push(ev(c));
      if (c.polarity === 'strength') { if (teacher) hit.strengthEvidence.push(ev(c)); continue; }
      let w = 0;
      if (c.polarity === 'need') w = teacher ? 2 : 1;
      else if (teacher) {
        // A neutral observation is corroborated when the teacher-selected level for that domain is "Below".
        const below = (area.domain === 'reading' && c.field === 'readingObservation' && d.readingLevel === 'Below Grade Level') ||
          (area.domain === 'mathematics' && c.field === 'mathObservation' && d.mathLevel === 'Below Grade Level');
        if (below) w = 1;
      }
      if (w === 0) continue;
      if (teacher) hit.teacherScore += w; else hit.parentScore += w;
      hit.needEvidence.push(ev(c));
    }
    if (hit.teacherScore + hit.parentScore > 0 || hit.strengthEvidence.length) hits.push(hit);
  });
  return hits;
}

function splitStrengths(text: string): { items: string[]; excluded: number } {
  let excluded = 0;
  const items = splitClauses(text.replace(/,\s+(?=(and\s+)?[A-Z])/g, '. ')).filter((s) => {
    if (DEFICIT_RE.test(s) || LABEL_RE.test(s)) { excluded++; return false; }
    return true;
  }).map((s) => cap(clean(s)));
  return { items, excluded };
}

function linkedConditions(a: AreaDef, d: LearnerData): Condition[] {
  return a.related.filter((c) => d.diagnosis.includes(c));
}

// ------------------------- recommendation builder -------------------------
function buildRecs(kind: 'accommodations' | 'strategies', ordered: Hit[], max: number, perArea: number): Recommendation[] {
  const map = new Map<string, Recommendation>();
  for (const h of ordered) {
    for (const text of h.area.accommodations && kind === 'accommodations' ? h.area.accommodations.slice(0, perArea) : h.area.strategies.slice(0, perArea)) {
      const item = h.needEvidence.filter((e) => e.field !== 'parentConcerns')[0] || h.needEvidence[0];
      const existing = map.get(text);
      if (existing) {
        if (!existing.areaLabels.includes(h.area.label)) existing.areaLabels.push(h.area.label);
        if (item && existing.evidence.length < 3 && !existing.evidence.some((e) => e.text === item.text)) existing.evidence.push(item);
      } else if (map.size < max) {
        map.set(text, { id: uid(kind === 'accommodations' ? 'acc' : 'str'), text, why: '', evidence: item ? [item] : [], areaLabels: [h.area.label] });
      }
    }
  }
  const list = Array.from(map.values());
  for (const r of list) {
    const labels = r.areaLabels.slice(0, 2).map((l) => lower(l)).join(' and ');
    const q = r.evidence[0] ? ` — for example: ${quote(r.evidence[0].text)}` : '';
    r.why = `Recommended because the teacher reported needs relating to ${labels}${q}.`;
  }
  return list;
}

const LEVERAGE: { re: RegExp; text: string }[] = [
  { re: /\b(oral|verbal|spoken|talk\w*|discussion|storytell\w*|speak\w*|communicat\w*)\b/i, text: 'Draw on the learner’s reported oral strengths: let the learner explain, retell or plan ideas aloud before recording anything, so that learning is not limited by the demands of reading, writing or number recording.' },
  { re: /\b(draw\w*|art|visual|building|hands-on|practical|experiment\w*|models?)\b/i, text: 'Build visual and hands-on elements (drawings, models, practical demonstrations) into instruction, drawing on the strength the teacher described.' },
  { re: /\b(typing|keyboard|computer|tablet)\b/i, text: 'Trial typed or dictated responses for extended tasks, building on the learner’s reported enjoyment of typing or technology.' },
];

function leverageStrategies(strengths: string[], hasNeed: boolean): Recommendation[] {
  if (!hasNeed) return [];
  const out: Recommendation[] = [];
  for (const rule of LEVERAGE) {
    const s = strengths.find((x) => rule.re.test(x));
    if (s) out.push({ id: uid('str'), text: rule.text, why: `Recommended because the teacher described this strength: ${quote(s)}. Strategies build on strengths rather than only addressing needs.`, evidence: [{ field: 'learnerStrengths', fieldLabel: FIELD_LABELS.learnerStrengths, text: clean(s) }], areaLabels: ['Learner strengths'] });
  }
  const interest = strengths.find((x) => /\b(enjoys?|loves?|interested in|passionate about)\b/i.test(x));
  if (interest) out.push({ id: uid('str'), text: 'Use the learner’s stated interests as contexts for practice tasks, to strengthen engagement and motivation.', why: `Recommended because the teacher described this interest: ${quote(interest)}.`, evidence: [{ field: 'learnerStrengths', fieldLabel: FIELD_LABELS.learnerStrengths, text: clean(interest) }], areaLabels: ['Learner strengths'] });
  return out.slice(0, 3);
}

// ============================ MAIN GENERATOR =============================
export function generateIEP(learner: LearnerData, opts: GenerateOptions = {}): IEPDocument {
  const d = learner;
  const now = opts.createdAt || new Date().toISOString();
  const reviewPeriod = opts.reviewPeriod || DEFAULT_REVIEW_PERIOD;
  const clauses = extractClauses(d);
  const languageNotes: string[] = [];
  const flaggedFields = new Set<string>();
  clauses.filter((c) => c.excluded).forEach((c) => flaggedFields.add(`${FIELD_LABELS[c.field]}:${c.excluded}`));
  flaggedFields.forEach((k) => {
    const [label, kind] = k.split(':');
    languageNotes.push(kind === 'deficit'
      ? `A statement in “${label}” used deficit-based wording and was left out of the generated text. Please restate it in observable, neutral terms.`
      : `A statement in “${label}” used a label rather than an observable behaviour and was left out of the generated text. Please describe what the learner does.`);
  });

  // 1. strengths
  const sp = splitStrengths(d.learnerStrengths);
  if (sp.excluded) languageNotes.push(`${sp.excluded} statement(s) in “Learner strengths” were left out because of wording. Please rephrase in neutral, asset-based terms.`);
  const strengths = sp.items;

  // 2. needs / evidence
  const hits = analyse(d, clauses);
  const documented = hits.filter((h) => h.teacherScore >= 2);
  const parentOnly = hits.filter((h) => h.teacherScore === 0 && h.parentScore > 0);
  const partial = hits.filter((h) => h.teacherScore === 1);
  const overlapOf = (h: Hit) => {
    if (!d.coOccurring) return 'n/a' as const;
    return linkedConditions(h.area, d).length >= 2 ? ('overlapping' as const) : ('distinct' as const);
  };
  const rank = (h: Hit) => h.teacherScore + (overlapOf(h) === 'overlapping' ? 1 : 0);
  const ranked = [...documented].sort((a, b) => rank(b) - rank(a) || a.index - b.index);

  // 3. prioritise goals: evidence-driven, max two per domain, five in total
  const selected: Hit[] = [];
  const perDomain: Record<string, number> = {};
  for (const h of ranked) {
    if (selected.length >= 5) break;
    if ((perDomain[h.area.domain] || 0) >= 2) continue;
    perDomain[h.area.domain] = (perDomain[h.area.domain] || 0) + 1;
    selected.push(h);
  }
  const selectedKeys = new Set(selected.map((h) => h.area.key));

  const overlapNote = (h: Hit): string => {
    if (!d.coOccurring) return '';
    const linked = linkedConditions(h.area, d);
    if (linked.length >= 2) return `This area is commonly associated with more than one selected identified need (${linked.join(' and ')}). It is addressed once to avoid duplication.`;
    if (linked.length === 1) return `This area is commonly associated with one selected identified need (${linked[0]}) and is supported here by teacher evidence in its own right.`;
    return 'This need is supported by teacher evidence and is not tied to a specific selected identified need.';
  };

  // 4. goals
  const goals: Goal[] = [];
  for (const h of selected) {
    const a = h.area;
    const baselineEv = h.allTeacher.find((e) => NUMERIC_BASELINE.test(e.text));
    const baseline = baselineEv ? `Teacher-reported: ${quote(baselineEv.text)}` : BASELINE_PLACEHOLDER;
    goals.push({
      id: uid('goal'), domain: a.domain, areaKey: a.key, areaLabel: a.label,
      condition: a.goal.condition, skill: a.goal.skill,
      criterion: baselineEv
        ? `[Criterion to be set by the teacher relative to the reported baseline — suggested form: ${a.goal.hint}]`
        : `[Criterion to be set by the teacher once a baseline has been measured — suggested form: ${a.goal.hint}]`,
      criterionHint: a.goal.hint, timeframe: TIMEFRAME_DEFAULT, baseline,
      evidence: h.needEvidence.filter((e) => e.field !== 'parentConcerns').slice(0, 3),
      why: `A goal is proposed for ${lower(a.label)} because the teacher reported: ${quote(h.needEvidence.filter((e) => e.field !== 'parentConcerns')[0]?.text || '')}${h.needEvidence.length > 1 ? ` (and ${h.needEvidence.length - 1} further related observation${h.needEvidence.length > 2 ? 's' : ''}).` : '.'} The diagnosis was not used to select this goal.`,
      overlapNote: overlapNote(h) || undefined,
      monitoring: { measure: a.goal.measure, method: a.goal.method, frequency: a.goal.frequency, collectedBy: 'Classroom teacher', reviewPoint: reviewPeriod },
    });
  }
  goals.sort((x, y) => DOMAIN_ORDER.indexOf(x.domain) - DOMAIN_ORDER.indexOf(y.domain));

  // 5. needs list
  const needs: NeedItem[] = [];
  for (const h of [...ranked]) {
    const has = selectedKeys.has(h.area.key);
    needs.push({
      id: uid('need'), domain: h.area.domain, areaKey: h.area.key,
      statement: `Requires support with ${lower(h.area.label)}.`,
      evidence: h.needEvidence.filter((e) => e.field !== 'parentConcerns').slice(0, 3), source: 'teacher', hasGoal: has,
      overlap: overlapOf(h),
      note: has ? overlapNote(h) : 'Documented need. Not prioritised for a goal in this draft, to keep the plan manageable. Revisit at the first review.',
    });
  }
  for (const h of parentOnly) {
    needs.push({
      id: uid('need'), domain: h.area.domain, areaKey: h.area.key,
      statement: `Parent/carer concern relating to ${lower(h.area.label)}.`, evidence: h.needEvidence.slice(0, 2), source: 'parent', hasGoal: false, overlap: 'n/a',
      note: 'Reported by the parent/carer only. [Teacher observation recommended] before a goal is written.',
    });
  }
  const levelNeeds: NeedItem[] = [];
  (['reading', 'mathematics'] as Domain[]).forEach((dom) => {
    const level = dom === 'reading' ? d.readingLevel : d.mathLevel;
    const has = documented.some((h) => h.area.domain === dom);
    if ((level === 'Below Grade Level' || level === 'Approaching Grade Level') && !has) {
      levelNeeds.push({
        id: uid('need'), domain: dom, areaKey: `${dom}_general`,
        statement: `The teacher reports ${dom === 'reading' ? 'reading' : 'mathematics'} as ${level.toLowerCase()}, but no specific skill area was described.`,
        evidence: [{ field: primaryField[dom], fieldLabel: `${dom === 'reading' ? 'Reading' : 'Mathematics'} level (teacher-selected)`, text: level }],
        source: 'teacher', hasGoal: false, overlap: 'n/a',
        note: '[Teacher observation recommended] A goal needs a specific, observable skill area and a baseline.',
      });
    }
  });
  needs.push(...levelNeeds);

  // 6. recommendations (from documented needs only)
  const orderedForRecs = [...selected, ...ranked.filter((h) => !selectedKeys.has(h.area.key))];
  const accommodations = buildRecs('accommodations', orderedForRecs, 10, 2);
  const strategies = [...buildRecs('strategies', orderedForRecs, 8, 2), ...leverageStrategies(strengths, orderedForRecs.length > 0)];

  // 7. present levels
  const includeWriting = !!d.writingObservation.trim() || documented.some((h) => h.area.domain === 'writing') || d.diagnosis.includes('Dysgraphia');
  const includeFunctional = !!d.behaviourSocial.trim() || documented.some((h) => h.area.domain === 'functional') || d.diagnosis.includes('ADHD');
  const domains: Domain[] = DOMAIN_ORDER.filter((x) => x === 'reading' || x === 'mathematics' || (x === 'writing' && includeWriting) || (x === 'functional' && includeFunctional));
  const presentLevels: PresentLevel[] = domains.map((dom) => {
    const pf = primaryField[dom];
    const own = clauses.filter((c) => c.field === pf && !c.excluded);
    const domNeeds = needs.filter((n) => n.domain === dom);
    const domGoals = goals.filter((g) => g.domain === dom);
    const level = dom === 'reading' ? d.readingLevel : dom === 'mathematics' ? d.mathLevel : '';
    let statusMessage = '';
    if (dom === 'reading' || dom === 'mathematics') {
      const nm = dom === 'reading' ? 'reading' : 'mathematics';
      if (level === 'Not Assessed') statusMessage = `[Not assessed] The teacher recorded ${nm} as not assessed. [Teacher observation recommended]`;
      else if (domNeeds.length === 0 && (level === 'At Grade Level' || level === 'Above Grade Level')) statusMessage = `The teacher reports ${nm} at or above grade level and did not describe a difficulty, so no need has been identified in this area.`;
      else if (domNeeds.length === 0) statusMessage = `[Information not provided] No specific ${nm} information was supplied.`;
    } else if (domNeeds.length === 0 && own.length === 0) statusMessage = '[Information not provided] No learner-specific information was supplied for this area.';
    else if (domNeeds.length === 0) statusMessage = 'The teacher’s observations did not describe a difficulty in this area.';
    return {
      domain: dom, title: DOMAIN_TITLES[dom],
      level: dom === 'reading' || dom === 'mathematics' ? (level ? `Teacher-reported level: ${level}` : '[Information not provided]') : 'No level recorded (based on teacher observations)',
      strengths: own.filter((c) => c.polarity === 'strength').map((c) => cap(clean(c.text))),
      needs: domNeeds.map((n) => n.statement),
      observations: own.filter((c) => c.polarity !== 'strength').map((c) => cap(clean(c.text))),
      baseline: domGoals.map((g) => `${g.areaLabel}: ${g.baseline}`),
      statusMessage,
    };
  });

  // 8. no-goal messages
  const noGoalMessages = domains.filter((dom) => !goals.some((g) => g.domain === dom)).map((dom) => {
    const level = dom === 'reading' ? d.readingLevel : dom === 'mathematics' ? d.mathLevel : '';
    const atOrAbove = level === 'At Grade Level' || level === 'Above Grade Level';
    return { domain: dom, message: `${DOMAIN_TITLES[dom]}: ${NO_GOAL_MESSAGE}${atOrAbove ? ' The teacher reports this area at or above grade level.' : ''}` };
  });

  // 9. missing-information system
  const missing: MissingItem[] = [];
  const addM = (kind: MissingItem['kind'], area: string, message: string) => missing.push({ id: uid('miss'), kind, area, message });
  (['reading', 'mathematics'] as Domain[]).forEach((dom) => {
    const nm = dom === 'reading' ? 'Reading' : 'Mathematics';
    const level = dom === 'reading' ? d.readingLevel : d.mathLevel;
    const obs = (dom === 'reading' ? d.readingObservation : d.mathObservation).trim();
    if (level === 'Not Assessed') addM('not_assessed', `${nm} level`, `[Not assessed] ${nm} level was recorded as not assessed. [Teacher observation recommended]`);
    if (!obs) {
      if (level === 'At Grade Level' || level === 'Above Grade Level') addM('not_relevant', `${nm} observation`, `${nm} is reported at or above grade level, so no ${nm.toLowerCase()} observation was needed for this draft.`);
      else addM('not_provided', `${nm} observation`, `[Information not provided] No ${nm.toLowerCase()} observation was supplied, so no ${nm.toLowerCase()} goal could be evidence-based. [Teacher observation recommended]`);
    }
  });
  if (!d.parentConcerns.trim()) addM('not_provided', 'Parent/carer concerns', 'Parent/carer concerns were not provided.');
  if (!d.behaviourSocial.trim()) addM('not_provided', 'Behaviour / social-emotional', '[Information not provided] Behaviour / social-emotional information was not supplied, so no functional area was assessed in this draft.');
  // Diagnosis is context only. It can prompt the teacher to add evidence, but never creates a need.
  const domainHasEvidence = (dom: Domain, textField: FieldKey) => documented.some((h) => h.area.domain === dom) || !!d[textField].trim();
  const prompt = (cond: Condition, dom: Domain, textField: FieldKey, areaName: string, levelOk: boolean) => {
    if (d.diagnosis.includes(cond) && (!domainHasEvidence(dom, textField) || !levelOk)) {
      addM('observation_recommended', areaName, `${cond} was supplied by the teacher as context only. No learner-specific ${areaName.toLowerCase()} information was supplied, so no ${areaName.toLowerCase()} goal was generated. [Teacher observation recommended]`);
    }
  };
  prompt('Dyslexia', 'reading', 'readingObservation', 'Reading', d.readingLevel !== 'Not Assessed');
  prompt('Dyscalculia', 'mathematics', 'mathObservation', 'Mathematics', d.mathLevel !== 'Not Assessed');
  prompt('Dysgraphia', 'writing', 'writingObservation', 'Writing', true);
  prompt('ADHD', 'functional', 'behaviourSocial', 'Behaviour and classroom functioning', true);
  goals.filter((g) => g.baseline === BASELINE_PLACEHOLDER).forEach((g) => addM('baseline_required', g.areaLabel, `[Baseline data required] ${g.areaLabel}: baseline data required before finalising this goal.`));
  [...parentOnly, ...partial].forEach((h) => addM('observation_recommended', h.area.label, `[Teacher observation recommended] ${h.area.label} was raised (parent/carer or a single unclear observation) without enough teacher evidence for a goal.`));
  levelNeeds.forEach((n) => addM('observation_recommended', n.domain === 'reading' ? 'Reading' : 'Mathematics', `[Teacher observation recommended] ${n.statement}`));

  // 10. overlap summary (co-occurring only)
  const overlapSummary: string[] = [];
  if (d.coOccurring) {
    const ov = ranked.filter((h) => overlapOf(h) === 'overlapping').map((h) => h.area.label);
    const di = ranked.filter((h) => overlapOf(h) === 'distinct').map((h) => h.area.label);
    overlapSummary.push(ov.length ? `Overlapping areas (relevant to more than one selected identified need, addressed once): ${ov.join('; ')}.` : 'No documented area was found that overlaps across the selected identified needs.');
    overlapSummary.push(di.length ? `Distinct areas (supported by separate teacher evidence): ${di.join('; ')}.` : 'No distinct documented areas were found.');
    overlapSummary.push(`Goals were limited to ${goals.length} (maximum five, two per area) so that the plan stays manageable for a learner with more than one identified need.`);
  }

  // 11. traceability of the pipeline
  const filled = OBS_FIELDS.filter((f) => d[f].trim()).length;
  const withBaseline = goals.filter((g) => g.baseline !== BASELINE_PLACEHOLDER).length;
  const trace: TraceStep[] = [
    { step: 'Teacher input received', detail: `Learner details, two levels, ${filled} of 5 optional text fields and a strengths description were supplied.` },
    { step: 'Data validation', detail: 'Required fields were present and within range. Wording was screened for deficit-based language.' },
    { step: 'Identify documented strengths', detail: `${strengths.length} strength statement(s) taken from the teacher’s description; further positive observations were placed in the relevant present-level section.` },
    { step: 'Identify documented educational needs', detail: `${documented.length} need(s) supported by teacher observations; ${parentOnly.length} raised by the parent/carer only; ${levelNeeds.length} general level-based note(s). The diagnosis was not used to identify needs.` },
    { step: 'Determine relevant academic/functional areas', detail: `Areas included: ${domains.map((x) => DOMAIN_TITLES[x]).join('; ')}.` },
    { step: 'Establish available baseline information', detail: `${withBaseline} of ${goals.length} goal(s) have a teacher-reported baseline; the rest are marked [Baseline data required].` },
    { step: 'Construct evidence-based measurable goals', detail: `${goals.length} goal(s) proposed. ${noGoalMessages.length} area(s) had insufficient evidence for a goal. No criterion or score was invented.` },
    { step: 'Recommend classroom accommodations', detail: `${accommodations.length} accommodation(s), each linked to documented need(s).` },
    { step: 'Recommend teacher strategies', detail: `${strategies.length} strateg${strategies.length === 1 ? 'y' : 'ies'}, including those building on the learner’s described strengths.` },
    { step: 'Create progress-monitoring plan', detail: `A measure, method, frequency and reviewer were set for each of the ${goals.length} goal(s). Review timeline: ${reviewPeriod}.` },
    { step: 'Generate IEP draft', detail: 'Draft assembled and marked for teacher review, editing and approval.' },
  ];

  const dx = d.diagnosis.length ? (d.coOccurring ? `Multiple/Co-occurring: ${d.diagnosis.join(' + ')}` : d.diagnosis.join(', ')) : '[Information not provided]';
  return {
    id: opts.id || uid('iep'),
    reference: `IEP-${new Date(now).getFullYear()}-${String(opts.sequence ?? 1).padStart(4, '0')}`,
    createdAt: now, updatedAt: now, status: 'Draft', learner: { ...d }, iepDate: now.slice(0, 10),
    diagnosisNote: `${dx}. Supplied by the teacher/user. IEP Assist does not diagnose, verify or infer diagnoses.`,
    reviewPeriod, strengths, languageNotes, presentLevels, needs, goals, noGoalMessages, accommodations, strategies, missing, overlapSummary, trace,
    generatorVersion: GENERATOR_VERSION,
  };
}

export type SectionKey = 'profile' | 'strengths' | 'presentLevels' | 'needs' | 'goals' | 'accommodations' | 'strategies' | 'monitoring' | 'missing';

/** Regenerate one section from the stored learner information, leaving everything else (including teacher edits elsewhere) untouched. */
export function regenerateSection(iep: IEPDocument, key: SectionKey): IEPDocument {
  const f = generateIEP(iep.learner, { reviewPeriod: iep.reviewPeriod, createdAt: iep.createdAt });
  const next: IEPDocument = { ...iep, updatedAt: new Date().toISOString() };
  switch (key) {
    case 'profile': next.diagnosisNote = f.diagnosisNote; next.iepDate = f.iepDate; break;
    case 'strengths': next.strengths = f.strengths; next.languageNotes = f.languageNotes; break;
    case 'presentLevels': next.presentLevels = f.presentLevels; break;
    case 'needs': next.needs = f.needs; next.overlapSummary = f.overlapSummary; break;
    case 'goals': next.goals = f.goals; next.noGoalMessages = f.noGoalMessages; break;
    case 'accommodations': next.accommodations = f.accommodations; break;
    case 'strategies': next.strategies = f.strategies; break;
    case 'monitoring': next.goals = iep.goals.map((g) => { const m = f.goals.find((x) => x.areaKey === g.areaKey); return m ? { ...g, monitoring: m.monitoring } : g; }); break;
    case 'missing': next.missing = f.missing; break;
  }
  return next;
}

export const mockGeneratorService: IEPGeneratorService = {
  generate: (learner, opts) => new Promise((resolve) => setTimeout(() => resolve(generateIEP(learner, opts)), 2800)),
};
