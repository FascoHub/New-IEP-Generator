import { Level, Condition, MULTIPLE } from '../types';

export const APP_NAME = 'IEP Assist';
export const APP_SUBTITLE = 'AI-Powered Individualized Education Plan Generator';
export const GENERATOR_VERSION = 'mock-rules-0.1';

// Grades are data-driven so more can be appended later.
export const GRADES: string[] = ['Primary 1', 'Primary 2', 'Primary 3', 'Primary 4', 'Primary 5', 'Primary 6'];
export const AGE_MIN = 4;
export const AGE_MAX = 14;

export const LEVELS: Level[] = [
  'Below Grade Level',
  'Approaching Grade Level',
  'At Grade Level',
  'Above Grade Level',
  'Not Assessed',
];

export const CONDITIONS: Condition[] = ['ADHD', 'Dyslexia', 'Dyscalculia', 'Dysgraphia'];

export const DIAGNOSIS_LABELS: Record<string, string> = {
  ADHD: 'ADHD — Attention-Deficit/Hyperactivity Disorder',
  Dyslexia: 'Dyslexia',
  Dyscalculia: 'Dyscalculia',
  Dysgraphia: 'Dysgraphia',
  [MULTIPLE]: 'Multiple/Co-occurring (select two or more)',
};
export const DIAGNOSIS_OPTIONS: string[] = [...CONDITIONS, MULTIPLE];

export const DIAGNOSIS_HELPER =
  'Select an existing diagnosis or identified educational need. This application does not diagnose learners.';

export const CONFIRMATION_TEXT =
  'I confirm that the information provided is accurate to the best of my knowledge and that I am authorised to use this information for educational planning.';

export const DRAFT_NOTICE =
  'This IEP is an AI-generated draft intended to support educational planning. Review, verify, and adapt all information, goals, accommodations, strategies, and progress-monitoring recommendations using available assessment evidence and professional judgement before implementation.';

export const REVIEW_PERIODS = ['Every 4–6 weeks', 'Every 6 weeks', 'Every 8 weeks', 'Once per term', 'Twice per term'];
export const DEFAULT_REVIEW_PERIOD = REVIEW_PERIODS[0];

export const TIMEFRAME_DEFAULT = 'by the end of the current school term [confirm date]';

export const NO_GOAL_MESSAGE =
  'No measurable goal was generated for this area because sufficient learner-specific evidence was not provided.';

// Wording that describes children in deficit terms. These are never echoed into
// generated text; the teacher is asked to rephrase in observable terms.
export const DEFICIT_TERMS = [
  'lazy', 'suffers from', 'suffering from', 'suffer from', 'problem child', 'weak learner', 'weak pupil',
  'incapable', 'defective', 'low child', 'slow learner', 'stupid', 'dull', 'retarded', 'hopeless',
];
// Labels that describe a judgement rather than an observable behaviour.
export const LABEL_TERMS = [
  'disruptive', 'naughty', 'troublemaker', 'bad behaviour', 'bad behavior', 'badly behaved', 'attention seeking', 'attention-seeking',
];

export const PIPELINE_LABELS = [
  'Teacher input received',
  'Data validation',
  'Identify documented strengths',
  'Identify documented educational needs',
  'Determine relevant academic/functional areas',
  'Establish available baseline information',
  'Construct evidence-based measurable goals',
  'Recommend classroom accommodations',
  'Recommend teacher strategies',
  'Create progress-monitoring plan',
  'Generate IEP draft',
];

export interface SourceRef {
  id: string;
  rank: number;
  name: string;
  url?: string;
  role: string;
  verification: 'Primary evidence' | 'Verified' | 'Partly verified' | 'Not verified';
  note: string;
}

export const VERIFIED_ON = '30 September 2026';

// Source hierarchy. Sources are framework/reference material only: nothing is copied,
// and no endorsement by any organisation is claimed or implied.
export const SOURCES: SourceRef[] = [
  {
    id: 'teacher',
    rank: 1,
    name: 'Teacher-provided learner information',
    role: 'Learner-specific evidence. The only source used to decide a learner’s needs, goals, accommodations and strategies.',
    verification: 'Primary evidence',
    note: 'Entered by the teacher and confirmed before generation.',
  },
  {
    id: 'iris',
    rank: 2,
    name: 'IRIS Center, Vanderbilt University — IEPs: Developing High-Quality Individualized Education Programs',
    url: 'https://iris.peabody.vanderbilt.edu/module/iep01/',
    role: 'Core framework: IEP structure, present levels, measurable goals, progress monitoring, individualisation.',
    verification: 'Partly verified',
    note: `Module landing page accessed on ${VERIFIED_ON}: it describes the module, its basis in US federal law (IDEA) and its note that state and local requirements may differ. The detailed module pages were not retrieved in this session, so the researcher should confirm the mapping to the module’s sections. The page is licensed CC BY-NC-ND 4.0, so no module text is reproduced.`,
  },
  {
    id: 'maryland',
    rank: 3,
    name: 'Maryland State Department of Education — IEP Essentials and IEP goal-writing guidance',
    url: 'https://marylandpublicschools.org/programs/documents/special-ed/training/iep-goal-writing-a.pdf',
    role: 'Goal-development and goal-checking framework: five goal components.',
    verification: 'Verified',
    note: `Official MSDE documents located on ${VERIFIED_ON} (excerpts reviewed). They describe five goal components: condition, behaviour, criteria (mastery and retention), method of measurement and timeframe. IEP Assist shows these five components on every goal. Full PDFs should still be read by the researcher.`,
  },
  {
    id: 'indiana',
    rank: 4,
    name: 'Indiana Department of Education — Special Education Transition Annual Goals One-Pager',
    url: 'https://www.in.gov/doe/files/Special-Education-Transition-Annual-Goals-One-Pager.pdf',
    role: 'Additional reference for goal structure and the reading, mathematics, writing and behaviour goal areas.',
    verification: 'Verified',
    note: `Retrieved and read on ${VERIFIED_ON}. It stresses goals drawn from present levels, one skill per goal, the SMART model and a named measurement tool. It is a transition-focused resource, so it is used only as a general goal-structure reference. Its examples are not reproduced, and its example percentages are deliberately not reused.`,
  },
  {
    id: 'ncpwd',
    rank: 5,
    name: 'National Commission for Persons with Disabilities (NCPWD), Nigeria',
    url: 'https://ncpwd.gov.ng/',
    role: 'Nigerian contextual and policy reference where applicable.',
    verification: 'Partly verified',
    note: `The NCPWD website was confirmed on ${VERIFIED_ON}. A 2024 NCPWD document on inclusion and access (ncpwd.gov.ng/pdfs/35document.pdf) refers to IEPs within school inclusion arrangements, but its full text was not reviewed and no NCPWD IEP template, checklist or framework was verified. IEP Assist therefore makes no claim about NCPWD requirements.`,
  },
];

export const SECURITY_PLACEHOLDERS: { name: string; status: string; note: string }[] = [
  { name: 'Secure authentication', status: 'Placeholder', note: 'Demonstration sign-in only. Production would use institutional single sign-on or verified accounts with multi-factor authentication.' },
  { name: 'Role-based access', status: 'Placeholder', note: 'Roles are selectable at sign-in for demonstration. Production would assign roles administratively.' },
  { name: 'Access control to learner records', status: 'Placeholder', note: 'Records would be limited to the teacher, authorised specialists and designated school leaders.' },
  { name: 'Encrypted transmission and storage', status: 'Not implemented', note: 'The prototype has no server. Production would require TLS in transit and encryption at rest.' },
  { name: 'Secure sessions', status: 'Placeholder', note: 'Production would use short-lived sessions with automatic timeout.' },
  { name: 'Audit logging', status: 'Prototype', note: 'Actions in this session are recorded in a local log (see Settings) to show how a production audit trail would look.' },
  { name: 'Data retention and deletion', status: 'Prototype', note: 'Records can be deleted individually or all at once. A retention schedule would be set by the institution.' },
  { name: 'Privacy notice', status: 'Draft text', note: 'A short notice is provided. It must be reviewed by the institution before any real use.' },
];

export const PRIVACY_NOTICE =
  'IEP Assist is a research prototype. It runs entirely in your browser and stores demonstration records only in this browser, if storage is available. Use fictional learner data only. No learner information is sent to any server or AI service. This prototype has not been assessed against Nigerian data-protection requirements or any institutional safeguarding policy, and it makes no claim of legal compliance.';

export const DEFAULT_THEME = { primary: '#12356b', accent: '#0b7a70', gold: '#e9b949' };
export const THEME_PRESETS: { id: string; name: string; theme: { primary: string; accent: string; gold: string } }[] = [
  { id: 'navy', name: 'Navy, teal and gold', theme: DEFAULT_THEME },
  { id: 'ocean', name: 'Ocean blue and amber', theme: { primary: '#0a4d8c', accent: '#0e7490', gold: '#f59e0b' } },
  { id: 'forest', name: 'Forest green and sand', theme: { primary: '#14532d', accent: '#0f766e', gold: '#d9a441' } },
  { id: 'plum', name: 'Plum and gold', theme: { primary: '#4c1d95', accent: '#0e7490', gold: '#f0b429' } },
  { id: 'crimson', name: 'Deep red and slate', theme: { primary: '#8f1d2c', accent: '#1e5a7a', gold: '#f2c14e' } },
];
