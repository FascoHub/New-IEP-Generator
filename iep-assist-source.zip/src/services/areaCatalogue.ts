import { Condition, Domain } from '../types';

// ---------------------------------------------------------------------------
// Area catalogue. Original wording, informed by common IEP goal structures.
// IMPORTANT: an area is only ever used when the teacher's own text contains
// evidence for it (see iepGenerator.ts). `related` lists the identified needs
// an area is commonly associated with and is used ONLY to describe overlap for
// co-occurring learners. It never creates a goal, an accommodation or a need.
// ---------------------------------------------------------------------------

export interface AreaDef {
  key: string;
  domain: Domain;
  label: string;
  cues: RegExp;
  related: Condition[];
  goal: {
    condition: string;
    skill: string; // begins with an observable verb
    hint: string; // how a criterion could be expressed (no numbers are supplied)
    measure: string;
    method: string;
    frequency: string;
  };
  accommodations: string[];
  strategies: string[];
}

export const AREAS: AreaDef[] = [
  // ------------------------------ READING ------------------------------
  {
    key: 'decoding', domain: 'reading', label: 'Decoding (reading unfamiliar words)',
    cues: /decod|sound(ing)? out|\bblend|letter[- ]sound|phonic|grapheme|syllab|unfamiliar words|guess(es|ing)? (words|from)/i,
    related: ['Dyslexia'],
    goal: {
      condition: 'When given short, grade-appropriate passages that include words the learner has not yet practised',
      skill: 'read unfamiliar words by applying taught letter–sound and syllable strategies',
      hint: 'accuracy across repeated short probes',
      measure: 'Decoding accuracy', method: 'Teacher-recorded oral reading sample (unfamiliar-word list or short passage)', frequency: 'Fortnightly',
    },
    accommodations: [
      'Allow additional time for reading tasks, and avoid unplanned reading aloud in front of peers',
      'Provide texts with decodable words and pre-teach key words before independent reading',
    ],
    strategies: [
      'Teach one letter–sound or syllable pattern at a time using explicit modelling (“I do, we do, you do”), followed by short daily word-building practice',
      'Give a reading window (a card with a slot) so the learner can focus on one word at a time during oral reading',
    ],
  },
  {
    key: 'fluency', domain: 'reading', label: 'Reading fluency',
    cues: /fluen|reads?\s+(very\s+)?slow|slow(ly)?\s+(when\s+)?read|word[- ]by[- ]word|halting|laborious|hesitat|\bpace\b|repeated reading|read(s|ing)?\b[^.]{0,25}\baloud/i,
    related: ['Dyslexia'],
    goal: {
      condition: 'When reading a familiar, grade-appropriate passage aloud',
      skill: 'read aloud with increasing accuracy and pace, pausing at punctuation',
      hint: 'words read correctly in a timed sample, or a teacher fluency rubric',
      measure: 'Reading fluency', method: 'Timed oral reading sample, or teacher fluency rubric', frequency: 'Weekly',
    },
    accommodations: [
      'Offer audio or teacher read-aloud versions alongside print for longer texts',
      'Reduce the amount of text per task by using shorter passages or chunked sections',
    ],
    strategies: [
      'Use repeated reading of one short passage (teacher models first, then echo or paired reading) and let the learner record progress on a simple chart',
      'Model phrasing by reading a sentence aloud and having the learner echo it, marking the pauses at punctuation',
    ],
  },
  {
    key: 'phonological', domain: 'reading', label: 'Phonological awareness',
    cues: /phonolog|rhym|segment|initial sounds?|phonemic|sounds in (spoken )?words/i,
    related: ['Dyslexia'],
    goal: {
      condition: 'During short oral activities without print',
      skill: 'identify, blend and segment the sounds in spoken words',
      hint: 'items correct in a short oral probe',
      measure: 'Phonological awareness', method: 'Teacher-led oral probe (blending and segmenting spoken words)', frequency: 'Fortnightly',
    },
    accommodations: ['Pair spoken instructions with a visual or gesture cue', 'Allow extra response time for sound-based questions'],
    strategies: [
      'Run five-minute daily oral games (rhyme matching, sound counting, blending with counters) before moving to print',
      'Use sound boxes or tokens so the learner pushes one token per sound while segmenting a word',
    ],
  },
  {
    key: 'wordRecognition', domain: 'reading', label: 'Word recognition',
    cues: /sight words?|word recognition|recogni[sz]es? (common |familiar )?words|high[- ]frequency|tricky words/i,
    related: ['Dyslexia'],
    goal: {
      condition: 'When shown a list of taught high-frequency words',
      skill: 'read taught high-frequency words automatically',
      hint: 'words read correctly in a short probe',
      measure: 'Word recognition', method: 'Flashcard or word-list probe', frequency: 'Weekly',
    },
    accommodations: ['Provide a personal word bank the learner can use during reading and writing tasks'],
    strategies: [
      'Introduce a small set of words at a time and revisit earlier words in a brief daily flashcard routine',
      'Link each new word to meaning with a picture, gesture or spoken sentence',
    ],
  },
  {
    key: 'comprehension', domain: 'reading', label: 'Reading comprehension',
    cues: /comprehen|understand(s|ing)?\s+(the\s+|what\s+|short\s+|longer\s+)?(texts?|stor(y|ies)|passages?|what (they|she|he) read)|retell|infer|main idea|answers?\s+(questions|comprehension)|explains? what happened/i,
    related: ['Dyslexia', 'ADHD'],
    goal: {
      condition: 'After reading, or listening to, a short grade-appropriate text',
      skill: 'answer literal and inferential questions about the text, using evidence from it',
      hint: 'questions answered correctly across several short texts',
      measure: 'Reading comprehension', method: 'Teacher questions with a short oral or written response record', frequency: 'Fortnightly',
    },
    accommodations: [
      'Allow oral responses to comprehension questions',
      'Pre-teach key vocabulary and give a short purpose-for-reading question before reading',
    ],
    strategies: [
      'Teach a simple routine (predict, read a chunk, retell it in one sentence) and think aloud while modelling it before the learner tries it independently',
      'Provide a graphic organiser (who, where, what happened) for recording key information while reading',
    ],
  },
  {
    key: 'vocabulary', domain: 'reading', label: 'Vocabulary',
    cues: /vocab|word meanings?|meaning of words|unknown words|new words/i,
    related: ['Dyslexia'],
    goal: {
      condition: 'When meeting taught topic words in reading and discussion',
      skill: 'explain the meaning of taught topic words and use them in a spoken sentence',
      hint: 'words explained and used correctly in a short oral check',
      measure: 'Vocabulary use', method: 'Short oral check of taught words', frequency: 'Fortnightly',
    },
    accommodations: ['Provide a picture-supported glossary for each topic'],
    strategies: ['Pre-teach three to five key words before each new topic, using a picture, a simple definition and an example sentence'],
  },
  // ---------------------------- WRITING ---------------------------------
  {
    key: 'spelling', domain: 'writing', label: 'Spelling',
    cues: /\bspell/i,
    related: ['Dyslexia', 'Dysgraphia'],
    goal: {
      condition: 'When spelling taught and topic words in dictation and in independent writing',
      skill: 'spell taught words correctly',
      hint: 'words spelled correctly in a short dictation',
      measure: 'Spelling accuracy', method: 'Short weekly dictation of taught words', frequency: 'Weekly',
    },
    accommodations: [
      'Assess subject knowledge without penalising spelling in tasks that are about content',
      'Provide word banks or a personal dictionary for topic vocabulary',
    ],
    strategies: [
      'Teach a small set of words each week with a multisensory routine (say, trace, write, cover, check) and revisit earlier words at spaced intervals',
      'Group words by shared spelling pattern so the learner can see and name the pattern',
    ],
  },
  {
    key: 'transcription', domain: 'writing', label: 'Handwriting and copying',
    cues: /handwrit|letter formation|form(s|ing)? (his |her |their )?letters|pencil grip|\bgrip\b|illegib|legib|uneven|hard to read|messy|copy(ing)?\s+(from|off)|copying|tires?\b[^.]{0,30}\bwrit|writing (speed|stamina)|hand (tires|aches|hurts)|letter (size|spacing)/i,
    related: ['Dysgraphia'],
    goal: {
      condition: 'When writing or copying a short sentence from a near-point model, on lined paper with a comfortable pencil grip',
      skill: 'form taught letters correctly and write a legible sentence with consistent size and spacing',
      hint: 'a legibility rating against a teacher checklist',
      measure: 'Handwriting legibility', method: 'Teacher checklist applied to a short writing sample (letter formation, size, spacing)', frequency: 'Fortnightly',
    },
    accommodations: [
      'Allow extra time for written tasks and reduce the amount of handwriting where handwriting is not the learning aim',
      'Offer alternative ways to record (typed, spoken or scribed) for content-focused tasks',
      'Provide printed notes or a desk copy instead of copying from the board',
    ],
    strategies: [
      'Teach letter formation in short daily sessions, with a consistent starting point and spoken cues, moving from tracing to independent writing',
      'Place the model on the learner’s desk rather than relying on the board, and chunk text into short lines',
    ],
  },
  {
    key: 'writtenExpression', domain: 'writing', label: 'Written expression and organisation',
    cues: /written expression|written (responses?|answers?)|writes? (only )?(short|one|two)|(write|writes|writing) (sentences?|a paragraph|stories)|compos(e|ition)|ideas (on paper|down)|paragraph|essay|story writing|organi[sz](e|es|ed|ing)\s+(\w+\s+){0,2}(ideas|writing|sentences|responses)/i,
    related: ['Dysgraphia', 'Dyslexia', 'ADHD'],
    goal: {
      condition: 'When given a familiar topic and a planning organiser or sentence frame',
      skill: 'write a short paragraph with a topic sentence, supporting details and a closing sentence',
      hint: 'a score on a teacher rubric for a short writing sample',
      measure: 'Written expression', method: 'Teacher rubric applied to a short writing sample', frequency: 'Fortnightly',
    },
    accommodations: [
      'Provide a planning organiser and sentence starters for written tasks',
      'Let the learner talk through, or record, their ideas before writing them down',
    ],
    strategies: [
      'Model planning aloud (talk, jot keywords, then write one sentence at a time) and give a short checklist for editing',
      'Separate composing from editing: ask the learner to focus first on ideas, then return to spelling and punctuation',
    ],
  },
  // ------------------------- MATHEMATICS --------------------------------
  {
    key: 'numberSense', domain: 'mathematics', label: 'Number sense and quantity',
    cues: /number sense|quantit(y|ies)|more than|less than|bigger|smaller|larger|greater|number relationships?|estimat|place value|compar(e|es|ing) numbers|magnitude|number line/i,
    related: ['Dyscalculia'],
    goal: {
      condition: 'When given concrete or pictorial representations of numbers within the range currently taught',
      skill: 'compare and order numbers and explain which is greater or less',
      hint: 'comparisons answered correctly across repeated short tasks',
      measure: 'Number sense', method: 'Short teacher-led task using objects or a number line', frequency: 'Weekly',
    },
    accommodations: [
      'Provide access to concrete materials (counters, base-ten blocks, number lines) throughout mathematics lessons',
      'Use the same visual representations (for example, ten-frames) consistently across lessons',
    ],
    strategies: [
      'Move from objects to drawings to numerals (concrete–pictorial–abstract) and ask the learner to explain each comparison aloud',
      'Use a number line or ten-frame in short daily warm-ups to build a sense of quantity',
    ],
  },
  {
    key: 'counting', domain: 'mathematics', label: 'Counting',
    cues: /skip[- ]count|counting (on|back|forward|backwards|in (twos|fives|tens))|count(s|ing)? (aloud|from|up to|to \d+)|one[- ]to[- ]one|miscount|lose(s)? count|counting (accuracy|skills?|difficult)/i,
    related: ['Dyscalculia'],
    goal: {
      condition: 'When given a set of objects or a number sequence within the range currently taught',
      skill: 'count accurately, including counting on from a given number',
      hint: 'sets counted correctly across repeated tasks',
      measure: 'Counting accuracy', method: 'Teacher observation checklist using objects', frequency: 'Weekly',
    },
    accommodations: ['Provide counters or a number track during counting tasks'],
    strategies: ['Practise touching and moving each object while counting aloud, then progress to counting on from a given number'],
  },
  {
    key: 'calculation', domain: 'mathematics', label: 'Calculation and number facts',
    cues: /calculat|\baddition\b|\badd(s|ing)?\b|subtract|multipl|\bdivi(sion|de|ding)\b|arithmetic|number facts?|times tables?|number bonds?|mental (maths|math|arithmetic)|computation|regroup|carry(ing)?|borrow/i,
    related: ['Dyscalculia'],
    goal: {
      condition: 'When given calculation problems within the operations currently taught',
      skill: 'solve calculations using a taught strategy, with concrete or pictorial support where needed',
      hint: 'problems solved correctly across repeated short probes',
      measure: 'Calculation accuracy', method: 'Short teacher-marked calculation probes', frequency: 'Weekly',
    },
    accommodations: [
      'Allow use of number lines, multiplication grids or manipulatives during calculation tasks',
      'Reduce the number of problems per task while keeping the same concept demand',
    ],
    strategies: [
      'Teach one strategy at a time (for example, making ten or counting on) with worked examples, and have the learner explain each step aloud',
      'Practise number facts in short, frequent sessions rather than long drills, and revisit earlier facts regularly',
    ],
  },
  {
    key: 'sequencing', domain: 'mathematics', label: 'Number sequencing',
    cues: /sequenc(e|ing) (of )?numbers|number sequences?|days of the week|months of the year|ordering numbers|counting sequence/i,
    related: ['Dyscalculia', 'Dyslexia'],
    goal: {
      condition: 'When given number cards or a familiar sequence',
      skill: 'put numbers or familiar items in the correct order and describe the pattern',
      hint: 'sequences ordered correctly across repeated tasks',
      measure: 'Sequencing accuracy', method: 'Teacher-observed card-sorting task', frequency: 'Fortnightly',
    },
    accommodations: ['Provide a visible number line or sequence strip during tasks'],
    strategies: ['Use physical cards that the learner can move and rearrange, and ask them to say the sequence aloud after ordering it'],
  },
  {
    key: 'problemSolving', domain: 'mathematics', label: 'Mathematical problem-solving and reasoning',
    cues: /word problems?|problem[- ]solving|solves? problems|reasoning|multi[- ]step|which operation|understand(s|ing)? (the )?(problem|question) in (maths|math)/i,
    related: ['Dyscalculia', 'ADHD'],
    goal: {
      condition: 'When given a short word problem set in a familiar context',
      skill: 'identify what is being asked, choose an operation and solve using a taught step-by-step routine',
      hint: 'a rubric score across the steps of the routine',
      measure: 'Problem-solving', method: 'Teacher rubric with one line per step of the routine', frequency: 'Fortnightly',
    },
    accommodations: [
      'Read word problems aloud, and allow drawings or manipulatives to represent them',
      'Provide a step-by-step problem-solving checklist',
    ],
    strategies: [
      'Teach a repeatable routine (read, underline the question, draw, choose the operation, solve, check) and model it with think-aloud before independent work',
      'Use familiar contexts for practice problems so the learner can focus on the mathematical structure',
    ],
  },
  // --------------- BEHAVIOUR / SOCIAL-EMOTIONAL / FUNCTIONAL -------------
  {
    key: 'attention', domain: 'functional', label: 'Sustained attention during tasks',
    cues: /attention|concentrat|\bfocus|distract|off[- ]task|on[- ]task|stays? (on|with) (task|work)|daydream|wander|loses? (track|focus)/i,
    related: ['ADHD'],
    goal: {
      condition: 'During independent work of a routine length in the classroom',
      skill: 'stay on task using an agreed strategy (for example, a task checklist or visual timer) with fewer adult reminders',
      hint: 'time on task or number of reminders across repeated observations',
      measure: 'On-task behaviour', method: 'Teacher observation across repeated short sessions (time on task or reminders needed)', frequency: 'Weekly',
    },
    accommodations: [
      'Seat the learner where distractions are limited and the teacher can give discreet cues',
      'Use a visual timer and short, clearly defined work periods',
    ],
    strategies: [
      'Give one instruction at a time, ask the learner to repeat it back, and use a discreet non-verbal cue to redirect',
      'Break longer independent work into short timed chunks with a brief check-in after each chunk',
    ],
  },
  {
    key: 'taskInitiation', domain: 'functional', label: 'Task initiation',
    cues: /initiat\w*|get(s|ting)? started|start(s|ing)?\b[^.]{0,25}\b(tasks?|work|activit\w+)|begin\w*\b[^.]{0,25}\b(tasks?|work)|slow to (start|begin)|(reminders?|prompts?) to (start|begin)/i,
    related: ['ADHD'],
    goal: {
      condition: 'When given an independent classroom task with clear, stepwise instructions',
      skill: 'begin the task within an agreed time, using a checklist or visual cue',
      hint: 'time taken to start, or number of prompts needed, across repeated observations',
      measure: 'Task initiation', method: 'Teacher observation log (time to start or number of prompts)', frequency: 'Weekly',
    },
    accommodations: [
      'Break independent tasks into smaller steps, with the first step made explicit',
      'Provide a written or visual checklist of the steps',
    ],
    strategies: [
      'State the first step aloud and stay near the learner for the first minute, then fade to a checklist as the learner begins independently',
      'Agree a simple start signal (for example, a card on the desk) so the learner knows what to do first',
    ],
  },
  {
    key: 'taskCompletion', domain: 'functional', label: 'Task completion',
    cues: /complet(e|es|ed|ing|ion)|finish(es|ed|ing)?|unfinished|incomplete|gives? up/i,
    related: ['ADHD'],
    goal: {
      condition: 'When given a classroom task of a length agreed as reasonable for the learner',
      skill: 'complete every step of the task, ticking each step off a checklist',
      hint: 'proportion of tasks completed independently over a set period',
      measure: 'Task completion', method: 'Teacher tracking sheet (tasks completed independently)', frequency: 'Weekly',
    },
    accommodations: [
      'Chunk tasks into shorter parts, each with a clear finish point',
      'Allow additional time for completion where speed is not the learning aim',
    ],
    strategies: [
      'Use a “first–then” or checklist format so the learner can see what is done and what remains',
      'Give brief, specific feedback each time a chunk is completed',
    ],
  },
  {
    key: 'organisation', domain: 'functional', label: 'Organisation of materials and time',
    cues: /organi[sz]ation|organi[sz](e|es|ed|ing) (their |his |her )?(belongings|materials|books|desk|bag|work ?space)|belongings|forgets? (to bring|books|pencils|homework|equipment)|loses? (pencils|books|materials|equipment)|time management|manages? (their |his |her )?time/i,
    related: ['ADHD'],
    goal: {
      condition: 'At the start and end of each school day, using a picture or written checklist',
      skill: 'organise the materials needed for the next lesson and place them ready for use',
      hint: 'checklist items completed independently across school days',
      measure: 'Organisation of materials', method: 'Teacher checklist at the start and end of the day', frequency: 'Weekly',
    },
    accommodations: ['Provide a visual checklist for daily routines and equipment', 'Colour-code subject books and folders'],
    strategies: ['Rehearse the start-of-day and end-of-day packing routine with the learner, withdrawing prompts gradually'],
  },
  {
    key: 'transitions', domain: 'functional', label: 'Transitions between activities',
    cues: /transition|changes? (of|in) (activity|routine)|moving between|switch(es|ing)? (tasks|activities)|routine changes|lining up/i,
    related: ['ADHD'],
    goal: {
      condition: 'During planned changes of activity in the school day',
      skill: 'move to the next activity after a warning signal, with an agreed number of prompts',
      hint: 'time taken or prompts needed across repeated transitions',
      measure: 'Transitions', method: 'Teacher observation record (time taken or prompts needed)', frequency: 'Weekly',
    },
    accommodations: [
      'Give advance warning before a change of activity (for example, a five-minute and a one-minute warning)',
      'Display a visual timetable and refer to it at each change',
    ],
    strategies: ['Preview the next activity briefly, name the first step and use one consistent signal for changes'],
  },
  {
    key: 'selfRegulation', domain: 'functional', label: 'Self-regulation and emotional regulation',
    cues: /self[- ]regulat|emotional regulat|frustrat|upset|meltdown|angry|anger|impuls|blurt|waiting (for )?(their |his |her )?turn|interrupt|fidget|restless|out of (their |his |her )?seat|leaves? (their |his |her )?seat|\bcalm/i,
    related: ['ADHD'],
    goal: {
      condition: 'When the learner feels frustrated or is asked to wait during class activities',
      skill: 'use an agreed strategy (for example, asking for a break or a calming routine) and return to the task',
      hint: 'level of prompting needed, or time taken to return to the task',
      measure: 'Use of self-regulation strategy', method: 'Teacher observation record (strategy used, level of prompting)', frequency: 'Weekly',
    },
    accommodations: [
      'Agree a discreet break signal and a quiet space the learner can use',
      'Build purposeful movement into lessons (for example, giving out materials)',
    ],
    strategies: [
      'Teach and rehearse the agreed strategy at calm moments, not only during difficulty, and acknowledge each use',
      'Give specific, immediate positive feedback when the learner waits or regulates',
    ],
  },
  {
    key: 'peerInteraction', domain: 'functional', label: 'Peer interaction',
    cues: /\bpeers?\b|friends?|plays? with|social interaction|group work|turn[- ]taking|shar(e|es|ing) (with|materials)|cooperat|collaborat|isolat|withdrawn|lonely|classmates/i,
    related: [],
    goal: {
      condition: 'During structured group activities with peers',
      skill: 'take turns and contribute an idea using a supported routine (for example, group roles or sentence starters)',
      hint: 'turns taken or contributions made across repeated group sessions',
      measure: 'Peer interaction', method: 'Teacher observation checklist during group work', frequency: 'Fortnightly',
    },
    accommodations: ['Assign clear roles in group work', 'Use structured pairing with a supportive peer'],
    strategies: ['Teach group roles and turn-taking phrases explicitly, model them and give feedback straight after group tasks'],
  },
  {
    key: 'participation', domain: 'functional', label: 'Classroom participation and confidence',
    cues: /participat|contribut|raises? (their |his |her )?hand|speaks? up|confidence|anxious|anxiety|\bshy\b|nervous|reluctan\w*/i,
    related: [],
    goal: {
      condition: 'During whole-class discussion, with the question shared in advance',
      skill: 'contribute an answer or idea using a prepared response or a chosen format',
      hint: 'contributions made across repeated lessons',
      measure: 'Classroom participation', method: 'Teacher tally of contributions across lessons', frequency: 'Weekly',
    },
    accommodations: ['Share questions before the lesson so the learner can prepare a response', 'Offer a choice of response format (spoken, written, drawn or pair-share)'],
    strategies: ['Use think–pair–share so the learner rehearses with a partner before answering', 'Acknowledge contributions privately as well as publicly'],
  },
];

export const AREA_BY_KEY: Record<string, AreaDef> = Object.fromEntries(AREAS.map((a) => [a.key, a]));

// Which learner-text fields may provide evidence for each domain.
export const DOMAIN_FIELDS: Record<Domain, string[]> = {
  reading: ['readingObservation', 'parentConcerns', 'behaviourSocial'],
  mathematics: ['mathObservation', 'parentConcerns'],
  writing: ['writingObservation', 'readingObservation', 'behaviourSocial', 'parentConcerns'],
  functional: ['behaviourSocial', 'readingObservation', 'mathObservation', 'writingObservation', 'parentConcerns'],
};

export const DOMAIN_TITLES: Record<Domain, string> = {
  reading: 'Reading',
  mathematics: 'Mathematics',
  writing: 'Writing and spelling',
  functional: 'Behaviour / social-emotional / functional',
};
