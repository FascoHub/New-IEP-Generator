import { LearnerData, FieldKey } from '../types';
import { AGE_MAX, AGE_MIN, DEFICIT_TERMS, LABEL_TERMS, GRADES, LEVELS } from './referenceData';

export type Errors = Record<string, string>;

export const FIELD_LABELS: Record<FieldKey, string> = {
  readingObservation: 'Reading observation',
  writingObservation: 'Writing observation',
  mathObservation: 'Mathematics observation',
  behaviourSocial: 'Behaviour / social-emotional',
  parentConcerns: 'Parent/carer concerns',
  learnerStrengths: 'Learner strengths',
};

export const TEXT_FIELDS: FieldKey[] = [
  'readingObservation', 'writingObservation', 'mathObservation', 'behaviourSocial', 'parentConcerns', 'learnerStrengths',
];

export const emptyLearner = (): LearnerData => ({
  learnerName: '', grade: '', age: '', diagnosis: [], coOccurring: false,
  readingLevel: '', readingObservation: '', writingObservation: '',
  mathLevel: '', mathObservation: '', behaviourSocial: '', parentConcerns: '', learnerStrengths: '',
});

export function validateStep(step: number, d: LearnerData): Errors {
  const e: Errors = {};
  if (step === 1) {
    if (d.learnerName.trim().length < 2) e.learnerName = 'Please enter the learner’s name.';
    if (!d.grade || !GRADES.includes(d.grade)) e.grade = 'Please choose the learner’s grade or class.';
    const a = d.age.trim();
    if (!a) e.age = 'Please enter the learner’s age in years.';
    else if (!/^\d{1,2}$/.test(a) || Number(a) < AGE_MIN || Number(a) > AGE_MAX)
      e.age = `Please enter a whole number between ${AGE_MIN} and ${AGE_MAX}, which is the usual age range for primary school.`;
    if (d.diagnosis.length === 0 && !d.coOccurring) e.diagnosis = 'Please select the learner’s existing diagnosis or identified educational need.';
    else if (d.coOccurring && d.diagnosis.length < 2) e.diagnosis = 'For Multiple/Co-occurring, please select at least two of the four conditions.';
    else if (!d.coOccurring && d.diagnosis.length > 1) e.diagnosis = 'To record more than one condition, please also select Multiple/Co-occurring.';
  }
  if (step === 2) {
    if (!d.readingLevel || !LEVELS.includes(d.readingLevel)) e.readingLevel = 'Please choose a reading level. Choose “Not Assessed” if you do not have this information.';
    if (!d.mathLevel || !LEVELS.includes(d.mathLevel)) e.mathLevel = 'Please choose a mathematics level. Choose “Not Assessed” if you do not have this information.';
  }
  if (step === 4) {
    if (d.learnerStrengths.trim().length < 8) e.learnerStrengths = 'Please describe at least one strength, interest or thing the learner does well.';
  }
  return e;
}

export function validateAll(d: LearnerData): { errors: Errors; firstStep: number } {
  const errors: Errors = { ...validateStep(1, d), ...validateStep(2, d), ...validateStep(4, d) };
  const stepOf = (k: string) => (['learnerName', 'grade', 'age', 'diagnosis'].includes(k) ? 1 : ['readingLevel', 'mathLevel'].includes(k) ? 2 : 4);
  const steps = Object.keys(errors).map(stepOf);
  return { errors, firstStep: steps.length ? Math.min(...steps) : 0 };
}

const esc = (t: string) => t.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
export const termRegex = (terms: string[]) => new RegExp(`\\b(${terms.map(esc).join('|')})\\b`, 'i');

export interface LanguageFlag { field: FieldKey; label: string; term: string; kind: 'deficit' | 'label' }

export function languageFlags(d: LearnerData): LanguageFlag[] {
  const out: LanguageFlag[] = [];
  const deficit = termRegex(DEFICIT_TERMS);
  const label = termRegex(LABEL_TERMS);
  for (const f of TEXT_FIELDS) {
    const text = d[f] || '';
    const m1 = text.match(deficit);
    if (m1) out.push({ field: f, label: FIELD_LABELS[f], term: m1[0].toLowerCase(), kind: 'deficit' });
    const m2 = text.match(label);
    if (m2) out.push({ field: f, label: FIELD_LABELS[f], term: m2[0].toLowerCase(), kind: 'label' });
  }
  return out;
}

export function softWarnings(d: LearnerData): string[] {
  const w: string[] = [];
  if ((d.readingLevel === 'Below Grade Level' || d.readingLevel === 'Approaching Grade Level') && !d.readingObservation.trim())
    w.push('Reading is below or approaching grade level, but no reading observation was added. Goals need specific observations to be evidence-based.');
  if ((d.mathLevel === 'Below Grade Level' || d.mathLevel === 'Approaching Grade Level') && !d.mathObservation.trim())
    w.push('Mathematics is below or approaching grade level, but no mathematics observation was added. Goals need specific observations to be evidence-based.');
  if (!d.behaviourSocial.trim()) w.push('No behaviour / social-emotional information was added. No functional goals will be generated.');
  if (!d.parentConcerns.trim()) w.push('No parent/carer concerns were added. The IEP will state that these were not provided.');
  return w;
}
