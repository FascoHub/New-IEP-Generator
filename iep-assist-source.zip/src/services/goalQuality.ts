import { Goal, QualityCheck } from '../types';
import { DEFICIT_TERMS } from './referenceData';

// A value is "pending" while it is empty or still contains a [bracketed placeholder].
export const isPending = (s: string): boolean => !s || !s.trim() || /\[[^\]]*\]/.test(s);

const OBSERVABLE_VERB =
  /^(read|identify|calculate|solve|write|spell|organi[sz]e|initiate|complete|respond|demonstrate|select|apply|count|compare|answer|explain|form|put|stay|begin|use|take|contribute|move|copy|decode)\b/i;

export const BASELINE_PLACEHOLDER = '[Baseline data required] Baseline data required before finalising this goal.';

export function formatGoal(g: Pick<Goal, 'condition' | 'skill' | 'criterion' | 'timeframe'>): string {
  return `${g.condition}, the learner will ${g.skill}, ${g.criterion}, ${g.timeframe}.`;
}

/**
 * Internal goal quality check. Recomputed live whenever the teacher edits a goal,
 * so a goal only "passes" once the teacher has supplied the missing baseline,
 * criterion and timeframe. The generator never invents these.
 */
export function checkGoal(g: Goal): QualityCheck[] {
  const baselineOk = !isPending(g.baseline);
  const criterionOk = !isPending(g.criterion);
  const text = `${g.condition} ${g.skill} ${g.criterion}`.toLowerCase();
  const deficitFree = !DEFICIT_TERMS.some((t) => text.includes(t));
  return [
    { id: 'evidence', label: 'Linked to documented evidence', passed: g.evidence.length > 0, note: g.evidence.length ? 'Linked to teacher-supplied information.' : 'No supporting teacher evidence is attached.' },
    { id: 'observable', label: 'Target skill is observable', passed: OBSERVABLE_VERB.test(g.skill.trim()), note: 'The skill should start with an observable verb such as read, solve, write or complete.' },
    { id: 'measurable', label: 'Measurable (criterion and method set)', passed: criterionOk && !!g.monitoring.method.trim(), note: criterionOk ? 'A criterion and a measurement method are set.' : 'The performance criterion is still to be set by the teacher.' },
    { id: 'baseline', label: 'Baseline available', passed: baselineOk, note: baselineOk ? 'A teacher-reported baseline is recorded.' : 'Baseline data required before finalising this goal.' },
    { id: 'criterion', label: 'Performance criterion appropriate', passed: criterionOk && baselineOk, note: 'A criterion can only be judged once a baseline is known.' },
    { id: 'timeframe', label: 'Timeframe confirmed', passed: !isPending(g.timeframe), note: 'Replace the suggested timeframe with a confirmed date.' },
    { id: 'individual', label: 'Individualised to this learner', passed: g.evidence.length > 0, note: 'Derived from this learner’s own information, not from a diagnosis label.' },
    { id: 'realistic', label: 'Realistic (teacher to confirm)', passed: criterionOk && baselineOk, note: 'Teacher judgement is needed once the baseline and criterion are set.' },
    { id: 'assumptions', label: 'Avoids unsupported assumptions', passed: deficitFree, note: deficitFree ? 'No deficit-based wording found.' : 'Deficit-based wording found. Please rephrase.' },
  ];
}

export function goalNeedsAttention(g: Goal): boolean {
  return checkGoal(g).some((c) => !c.passed);
}
