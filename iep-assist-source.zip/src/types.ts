// ---------------------------------------------------------------------------
// Data model — IEP Assist (research prototype)
// Teacher-provided evidence is the primary input. Diagnosis is context only.
// ---------------------------------------------------------------------------

export type Level =
  | 'Below Grade Level'
  | 'Approaching Grade Level'
  | 'At Grade Level'
  | 'Above Grade Level'
  | 'Not Assessed';

export type Condition = 'ADHD' | 'Dyslexia' | 'Dyscalculia' | 'Dysgraphia';
export const MULTIPLE = 'Multiple/Co-occurring' as const;

export type FieldKey =
  | 'readingObservation'
  | 'writingObservation'
  | 'mathObservation'
  | 'behaviourSocial'
  | 'parentConcerns'
  | 'learnerStrengths';

export interface LearnerData {
  learnerName: string;
  grade: string;
  age: string; // kept as string so that a missing age is never fabricated
  diagnosis: Condition[]; // e.g. ["ADHD", "Dyslexia"]
  coOccurring: boolean; // true when "Multiple/Co-occurring" was selected
  readingLevel: Level | '';
  readingObservation: string;
  writingObservation: string; // optional addition so writing evidence has a home
  mathLevel: Level | '';
  mathObservation: string;
  behaviourSocial: string;
  parentConcerns: string;
  learnerStrengths: string;
}

export type Domain = 'reading' | 'mathematics' | 'writing' | 'functional';

export interface EvidenceItem {
  field: FieldKey;
  fieldLabel: string;
  text: string;
}

export type MissingKind =
  | 'not_provided'
  | 'baseline_required'
  | 'observation_recommended'
  | 'not_assessed'
  | 'not_relevant';

export interface MissingItem {
  id: string;
  kind: MissingKind;
  area: string;
  message: string;
  resolved?: boolean;
}

export interface QualityCheck {
  id: string;
  label: string;
  passed: boolean;
  note: string;
}

export interface Monitoring {
  measure: string;
  method: string;
  frequency: string;
  collectedBy: string;
  reviewPoint: string;
}

export interface Goal {
  id: string;
  domain: Domain;
  areaKey: string;
  areaLabel: string;
  condition: string;
  skill: string;
  criterion: string;
  criterionHint: string;
  timeframe: string;
  baseline: string;
  evidence: EvidenceItem[];
  why: string;
  overlapNote?: string;
  monitoring: Monitoring;
}

export interface NeedItem {
  id: string;
  domain: Domain;
  areaKey: string;
  statement: string;
  evidence: EvidenceItem[];
  source: 'teacher' | 'parent';
  hasGoal: boolean;
  overlap: 'overlapping' | 'distinct' | 'n/a';
  note: string;
}

export interface Recommendation {
  id: string;
  text: string;
  why: string;
  evidence: EvidenceItem[];
  areaLabels: string[];
}

export interface PresentLevel {
  domain: Domain;
  title: string;
  level: string;
  strengths: string[];
  needs: string[];
  observations: string[];
  baseline: string[];
  statusMessage: string;
}

export interface TraceStep {
  step: string;
  detail: string;
}

export type IEPStatus = 'Draft' | 'Completed';

export interface IEPDocument {
  id: string;
  reference: string;
  createdAt: string;
  updatedAt: string;
  status: IEPStatus;
  learner: LearnerData;
  iepDate: string;
  diagnosisNote: string;
  reviewPeriod: string;
  strengths: string[];
  languageNotes: string[];
  presentLevels: PresentLevel[];
  needs: NeedItem[];
  goals: Goal[];
  noGoalMessages: { domain: Domain; message: string }[];
  accommodations: Recommendation[];
  strategies: Recommendation[];
  missing: MissingItem[];
  overlapSummary: string[];
  trace: TraceStep[];
  generatorVersion: string;
}

export interface AuditEvent {
  ts: string;
  action: string;
  detail: string;
}

export interface ThemeSettings { primary: string; accent: string; gold: string }
export interface AppSettings {
  revealNames: boolean;
  defaultReviewPeriod: string;
  appName: string;
  theme: ThemeSettings;
  showHero: boolean;
  textSize: 'normal' | 'large';
}
