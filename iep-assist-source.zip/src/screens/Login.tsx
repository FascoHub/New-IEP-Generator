import React, { useState } from 'react';
import { Button, Callout, Icon, InputField, Logo, Modal, SelectField } from '../components/ui';
import { APP_NAME, APP_SUBTITLE, PRIVACY_NOTICE } from '../services/referenceData';

export const Login: React.FC<{ onLogin: (name: string, role: string) => void; appName?: string }> = ({ onLogin, appName = APP_NAME }) => {
  const [email, setEmail] = useState('teacher@demo.school');
  const [pw, setPw] = useState('demo-password');
  const [role, setRole] = useState('Class teacher');
  const [priv, setPriv] = useState(false);
  const [err, setErr] = useState('');
  const submit = () => {
    if (!email.includes('@')) { setErr('Please enter a valid email address.'); return; }
    if (pw.length < 4) { setErr('Please enter a password.'); return; }
    onLogin(email.split('@')[0].replace(/[._]/g, ' '), role);
  };
  return (
    <main id="main" className="mx-auto grid min-h-screen max-w-6xl items-center gap-10 px-5 py-10 lg:grid-cols-2">
      <section className="hero rounded-3xl p-7 shadow-card sm:p-10">
        <div className="mb-6 flex items-center gap-3"><Logo size={44} /><div><p className="text-2xl font-extrabold">{appName}</p><p className="text-sm text-white/80">{APP_SUBTITLE}</p></div></div>
        <h1 className="text-3xl font-bold leading-tight sm:text-4xl">From what you observe to a draft plan you can trust.</h1>
        <p className="mt-4 max-w-xl text-lg text-white/85">Tell us about the learner, review, generate a draft IEP, then edit and approve it. Goals appear only where your own evidence supports them.</p>
        <ul className="mt-6 space-y-3 text-[15px]">
          {['Does not diagnose. Your information leads; the diagnosis is context only.', 'Never invents baselines, scores or family information.', 'Every recommendation shows why it was made.', 'You stay in control: every section can be edited.'].map((t) => (
            <li key={t} className="flex gap-3"><span className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-[#0b1b34]" style={{ background: 'var(--gold)' }}><Icon name="check" size={14} /></span>{t}</li>
          ))}
        </ul>
        <p className="mt-8 text-xs text-white/70">Postgraduate research prototype: Effects of an AI-Powered IEP Generator on Teachers’ Instructional Planning, Gbagada LGA, Lagos State.</p>
      </section>
      <section className="card rounded-2xl border border-line bg-surface p-6 shadow-card sm:p-8" aria-labelledby="login-h">
        <h2 id="login-h" className="text-xl font-bold">Sign in</h2>
        <p className="mb-4 mt-1 text-sm text-muted">Demonstration sign-in. No real authentication takes place.</p>
        <div className="space-y-4">
          <InputField id="email" label="School email" type="email" required value={email} onChange={(e) => setEmail(e.target.value)} autoComplete="off" />
          <InputField id="pw" label="Password" type="password" required value={pw} onChange={(e) => setPw(e.target.value)} autoComplete="off" />
          <SelectField id="role" label="Role (demonstration of role-based access)" value={role} onChange={setRole} options={['Class teacher', 'Special-needs coordinator', 'School leader']} placeholder="Choose role" />
          {err && <p role="alert" className="text-sm font-medium text-danger">{err}</p>}
          <Button variant="primary" icon="lock" className="w-full" onClick={submit}>Sign in to demonstration</Button>
        </div>
        <Callout tone="warn" className="mt-5" title="Fictional data only">Do not enter real learner information. All example learners are invented.</Callout>
        <button type="button" onClick={() => setPriv(true)} className="mt-4 text-sm font-semibold text-brand-text underline">Read the privacy notice</button>
      </section>
      {priv && <Modal title="Privacy notice (draft)" onClose={() => setPriv(false)} actions={<Button variant="primary" onClick={() => setPriv(false)}>Close</Button>}><p>{PRIVACY_NOTICE}</p></Modal>}
    </main>
  );
};
