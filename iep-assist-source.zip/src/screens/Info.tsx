import React, { useMemo, useState } from 'react';
import { AppSettings, AuditEvent, IEPDocument, LearnerData } from '../types';
import { Button, Callout, Icon, Modal, Tag } from '../components/ui';
import { REVIEW_PERIODS, SECURITY_PLACEHOLDERS, SOURCES, PRIVACY_NOTICE, DEFICIT_TERMS, THEME_PRESETS, DEFAULT_THEME, APP_NAME } from '../services/referenceData';
import { SCENARIOS } from '../services/scenarios';
import { generateIEP } from '../services/iepGenerator';
import { fmt } from './Dashboard';

const lum = (hex: string) => { const m = /^#?([0-9a-f]{6})$/i.exec(hex); if (!m) return 0; const n = parseInt(m[1], 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255].map((v) => { const c = v / 255; return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4); }).reduce((a, c, i) => a + c * [0.2126, 0.7152, 0.0722][i], 0); };
const contrastWhite = (hex: string) => 1.05 / (lum(hex) + 0.05);

const Appearance: React.FC<{ settings: AppSettings; onSettings: (s: AppSettings) => void }> = ({ settings, onSettings }) => {
  const t = settings.theme;
  const setT = (p: Partial<typeof t>) => onSettings({ ...settings, theme: { ...t, ...p } });
  const Pick: React.FC<{ id: string; label: string; k: 'primary' | 'accent' | 'gold'; note: string; min?: number }> = ({ id, label, k, note, min }) => {
    const ratio = contrastWhite(t[k]);
    return (
      <div className="rounded-xl border border-line p-3">
        <label htmlFor={id} className="mb-1 block text-sm font-semibold">{label}</label>
        <div className="flex items-center gap-2"><input id={id} type="color" value={t[k]} onChange={(e) => setT({ [k]: e.target.value })} className="h-11 w-14 cursor-pointer rounded-lg border border-line bg-surface p-1" />
          <input aria-label={`${label} hex code`} value={t[k]} onChange={(e) => /^#[0-9a-f]{0,6}$/i.test(e.target.value) && setT({ [k]: e.target.value })} className="min-h-[44px] w-28 rounded-lg border border-line bg-surface px-2 font-mono text-sm" /></div>
        <p className="mt-1 text-xs text-muted">{note}</p>
        {min && ratio < min && <p className="mt-1 text-xs font-semibold text-danger" role="alert">Low contrast with white text ({ratio.toFixed(1)}:1). Choose a darker colour for readability (at least {min}:1).</p>}
      </div>);
  };
  return (
    <section className="card space-y-4 rounded-2xl border border-line bg-surface p-5 shadow-card" aria-labelledby="sap" style={{ borderLeft: '6px solid var(--gold)' }}>
      <h2 id="sap" className="text-xl font-bold">Appearance</h2>
      <p className="text-sm text-muted">Change the look of the app. Changes apply immediately and are saved in this browser.</p>
      <fieldset><legend className="mb-2 text-sm font-semibold">Colour palette presets</legend>
        <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">{THEME_PRESETS.map((p) => {
          const on = p.theme.primary === t.primary && p.theme.accent === t.accent && p.theme.gold === t.gold;
          return (<button key={p.id} type="button" aria-pressed={on} onClick={() => setT(p.theme)} className={`flex items-center gap-3 rounded-xl border p-3 text-left text-sm font-semibold hover:bg-surface-2 ${on ? 'border-2' : 'border-line'}`} style={on ? { borderColor: 'var(--gold)' } : undefined}>
            <span className="flex overflow-hidden rounded-lg" aria-hidden="true">{[p.theme.primary, p.theme.accent, p.theme.gold].map((c) => <span key={c} className="h-8 w-6" style={{ background: c }} />)}</span>{p.name}{on && <Icon name="check" size={16} className="ml-auto" />}</button>);
        })}</div></fieldset>
      <div className="grid gap-3 md:grid-cols-3">
        <Pick id="c1" label="Primary colour" k="primary" note="Buttons, headings accents, banner." min={4.5} />
        <Pick id="c2" label="Secondary colour" k="accent" note="Teal accents, section bars, cards." min={3} />
        <Pick id="c3" label="Highlight colour" k="gold" note="Logo, highlights, focus ring." />
      </div>
      <div className="grid gap-4 sm:grid-cols-2">
        <div><label htmlFor="appn" className="mb-1 block text-sm font-semibold">Application name</label><input id="appn" value={settings.appName} maxLength={30} onChange={(e) => onSettings({ ...settings, appName: e.target.value || APP_NAME })} className="min-h-[44px] w-full rounded-xl border border-line bg-surface px-3" /></div>
        <div><label htmlFor="tsz" className="mb-1 block text-sm font-semibold">Text size</label><select id="tsz" value={settings.textSize} onChange={(e) => onSettings({ ...settings, textSize: e.target.value as 'normal' | 'large' })} className="min-h-[44px] w-full rounded-xl border border-line bg-surface px-3"><option value="normal">Normal</option><option value="large">Large</option></select></div>
      </div>
      <label className="flex items-center gap-3 text-sm font-semibold"><input type="checkbox" checked={settings.showHero} onChange={(e) => onSettings({ ...settings, showHero: e.target.checked })} className="h-5 w-5 accent-[var(--brand)]" />Show the welcome banner on the dashboard</label>
      <Button icon="refresh" onClick={() => onSettings({ ...settings, theme: DEFAULT_THEME, appName: APP_NAME, textSize: 'normal', showHero: true })}>Reset appearance to default</Button>
    </section>
  );
};

export const Settings: React.FC<{ settings: AppSettings; onSettings: (s: AppSettings) => void; audit: AuditEvent[]; onDeleteAll: () => void }> = ({ settings, onSettings, audit, onDeleteAll }) => {
  const [del, setDel] = useState(false);
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold sm:text-3xl">Settings</h1>
      <Appearance settings={settings} onSettings={onSettings} />
      <section className="card space-y-4 rounded-2xl border border-line bg-surface p-5 shadow-card" aria-labelledby="s1">
        <h2 id="s1" className="text-xl font-bold">Preferences and privacy</h2>
        <label className="flex items-start gap-3 text-sm"><input type="checkbox" checked={settings.revealNames} onChange={(e) => onSettings({ ...settings, revealNames: e.target.checked })} className="mt-1 h-5 w-5 accent-[var(--brand)]" /><span><span className="font-semibold">Show full learner names on the dashboard</span><br /><span className="text-muted">Off by default. Names appear as initials to limit exposure of learner information.</span></span></label>
        <div><label htmlFor="drp" className="mb-1 block text-sm font-semibold">Default review timeline for new IEPs</label>
          <select id="drp" value={settings.defaultReviewPeriod} onChange={(e) => onSettings({ ...settings, defaultReviewPeriod: e.target.value })} className="min-h-[44px] rounded-xl border border-line bg-surface px-3">{REVIEW_PERIODS.map((p) => <option key={p}>{p}</option>)}</select></div>
        <div className="flex flex-wrap items-center gap-3 border-t border-line pt-4"><Button variant="danger" icon="trash" onClick={() => setDel(true)}>Delete all saved records</Button><span className="text-sm text-muted">Data retention: a placeholder. An institution would set its own schedule.</span></div>
        <p className="text-sm text-muted">{PRIVACY_NOTICE}</p>
      </section>
      <section className="card rounded-2xl border border-line bg-surface p-5 shadow-card" aria-labelledby="s2">
        <h2 id="s2" className="mb-1 text-xl font-bold">Security and privacy architecture</h2>
        <p className="mb-3 text-sm text-muted">Placeholders showing where production safeguards would sit. No legal compliance is claimed. Nigerian data-protection requirements and institutional safeguarding policies must be reviewed before any real deployment.</p>
        <ul className="divide-y divide-line">{SECURITY_PLACEHOLDERS.map((p) => <li key={p.name} className="flex flex-wrap items-start gap-3 py-3 text-sm"><span className="min-w-[14rem] font-semibold">{p.name}</span><Tag tone={p.status === 'Not implemented' ? 'danger' : 'warn'}>{p.status}</Tag><span className="min-w-0 flex-1 text-muted">{p.note}</span></li>)}</ul>
      </section>
      <section className="card rounded-2xl border border-line bg-surface p-5 shadow-card" aria-labelledby="s3">
        <h2 id="s3" className="mb-1 text-xl font-bold">Audit log (this browser)</h2>
        {audit.length === 0 ? <p className="text-sm text-muted">No events yet.</p> : <div className="overflow-x-auto"><table className="w-full text-left text-sm"><caption className="sr-only">Recent audit events</caption><thead><tr className="border-b border-line text-muted"><th className="py-2 pr-3">Time</th><th className="pr-3">Action</th><th>Detail</th></tr></thead><tbody>{audit.slice(0, 30).map((a, i) => <tr key={i} className="border-b border-line"><td className="whitespace-nowrap py-2 pr-3">{new Date(a.ts).toLocaleString('en-GB')}</td><td className="pr-3 font-semibold">{a.action}</td><td>{a.detail}</td></tr>)}</tbody></table></div>}
      </section>
      <section className="card rounded-2xl border border-line bg-surface p-5 shadow-card" aria-labelledby="s4">
        <h2 id="s4" className="mb-1 text-xl font-bold">Reference sources and verification status</h2>
        <p className="mb-3 text-sm text-muted">Sources are framework and reference material only. Nothing is copied and no organisation endorses this application.</p>
        <ol className="space-y-3">{SOURCES.map((s) => <li key={s.id} className="rounded-xl border border-line p-4 text-sm"><div className="flex flex-wrap items-center gap-2"><span className="font-bold">{s.rank}. {s.name}</span><Tag tone={s.verification === 'Verified' || s.verification === 'Primary evidence' ? 'ok' : 'warn'}>{s.verification}</Tag></div><p className="mt-1">{s.role}</p><p className="mt-1 text-muted">{s.note}</p>{s.url && <a className="mt-1 inline-block break-all font-semibold text-brand-text underline" href={s.url} target="_blank" rel="noopener noreferrer">{s.url}</a>}</li>)}</ol>
      </section>
      {del && <Modal title="Delete all saved records?" onClose={() => setDel(false)} actions={<><Button onClick={() => setDel(false)}>Cancel</Button><Button variant="danger" icon="trash" onClick={() => { onDeleteAll(); setDel(false); }}>Delete everything</Button></>}><p>This removes all IEPs, the audit log and settings stored in this browser. It cannot be undone.</p></Modal>}
    </div>
  );
};

export const Help: React.FC = () => (
  <div className="space-y-6">
    <h1 className="text-2xl font-bold sm:text-3xl">Help</h1>
    <section className="card rounded-2xl border border-line bg-surface p-5 shadow-card"><h2 className="mb-2 text-xl font-bold">How IEP Assist works</h2>
      <p className="mb-3 text-sm">Tell us about the learner → Review → Generate IEP → Review/Edit → Save/Export.</p>
      <Callout title="The central idea">The diagnosis does not define the learner. The learner’s documented strengths, needs, context and educational evidence guide the IEP.</Callout>
      <ul className="mt-4 list-disc space-y-2 pl-5 text-sm leading-relaxed">
        <li>The application does not diagnose. The diagnosis you select is background context only.</li>
        <li>A goal is proposed only where your observations support it. Otherwise you will see: “No measurable goal was generated for this area because sufficient learner-specific evidence was not provided.”</li>
        <li>Baselines, scores and family information are never invented. Missing items are marked, for example [Baseline data required].</li>
        <li>Every goal, accommodation and strategy has a “Why was this recommended?” panel showing your own words.</li>
        <li>Every section can be edited. The draft is a starting point for professional judgement.</li>
      </ul></section>
    <section className="card rounded-2xl border border-line bg-surface p-5 shadow-card"><h2 className="mb-2 text-xl font-bold">Writing helpful observations</h2>
      <div className="grid gap-4 text-sm md:grid-cols-2">
        <div className="rounded-xl bg-ok-soft p-4"><p className="mb-1 font-bold">Helpful</p><p>“Sounds out short words but stops at longer words and guesses from the first letter. Read 24 words correctly in one minute on a familiar passage.”</p></div>
        <div className="rounded-xl bg-danger-soft p-4"><p className="mb-1 font-bold">Less helpful</p><p>“A weak reader with a bad attitude.” Labels and judgements cannot become measurable goals. They are left out of the draft.</p></div>
      </div>
      <p className="mt-3 text-sm text-muted">Wording screened and left out of generated text includes: {DEFICIT_TERMS.slice(0, 8).join(', ')} and similar. Prefer “requires support with…”, “benefits from…”, “shows strength in…”.</p></section>
    <section className="card rounded-2xl border border-line bg-surface p-5 shadow-card"><h2 className="mb-2 text-xl font-bold">Keyboard and accessibility</h2>
      <p className="text-sm leading-relaxed">All controls can be used with the keyboard. In the diagnosis selector, use the arrow keys to move, Enter to select and Escape to close. Progress steps, errors and status messages are announced to screen readers. Status is never shown by colour alone.</p></section>
  </div>
);

export const ScenarioTests: React.FC<{ onLoad: (d: LearnerData) => void; onOpenIEP: (i: IEPDocument) => void }> = ({ onLoad, onOpenIEP }) => {
  const results = useMemo(() => SCENARIOS.map((s) => { const iep = generateIEP(s.data, { sequence: 900 }); return { s, iep, checks: s.expect(iep) }; }), []);
  const total = results.reduce((n, r) => n + r.checks.length, 0);
  const passed = results.reduce((n, r) => n + r.checks.filter((c) => c.pass).length, 0);
  const count = (i: IEPDocument, d: string) => i.goals.filter((g) => g.domain === d).length;
  return (
    <div className="space-y-6">
      <div><h1 className="text-2xl font-bold sm:text-3xl">Scenario tests</h1>
        <p className="max-w-3xl text-sm text-muted">Seven fictional learners are run through the generator live. The comparison shows that output changes with the evidence supplied, not with the diagnosis label. Scenario 6 checks that missing information is flagged instead of invented.</p></div>
      <Callout tone={passed === total ? 'ok' : 'danger'} title={`${passed} of ${total} checks passed`}>Checks are recalculated each time this page opens.</Callout>
      <section className="card overflow-x-auto rounded-2xl border border-line bg-surface p-5 shadow-card" aria-labelledby="cmp"><h2 id="cmp" className="mb-3 text-xl font-bold">Comparison</h2>
        <table className="w-full min-w-[42rem] text-left text-sm"><caption className="sr-only">Goals generated per domain for each scenario</caption>
          <thead><tr className="border-b border-line text-muted"><th scope="col" className="py-2 pr-3">Scenario</th><th scope="col" className="pr-3">Diagnosis (context)</th><th scope="col" className="pr-3">Reading</th><th scope="col" className="pr-3">Maths</th><th scope="col" className="pr-3">Writing</th><th scope="col" className="pr-3">Functional</th><th scope="col" className="pr-3">Missing items</th><th scope="col">Checks</th></tr></thead>
          <tbody>{results.map(({ s, iep, checks }) => <tr key={s.id} className="border-b border-line align-top"><th scope="row" className="py-2 pr-3 font-semibold">{s.title.split(' — ')[0]}</th><td className="pr-3">{iep.learner.diagnosis.join(' + ')}</td><td className="pr-3">{count(iep, 'reading')}</td><td className="pr-3">{count(iep, 'mathematics')}</td><td className="pr-3">{count(iep, 'writing')}</td><td className="pr-3">{count(iep, 'functional')}</td><td className="pr-3">{iep.missing.filter((m) => m.kind !== 'not_relevant').length}</td><td>{checks.filter((c) => c.pass).length}/{checks.length}</td></tr>)}</tbody></table>
      </section>
      {results.map(({ s, iep, checks }) => (
        <section key={s.id} className="card rounded-2xl border border-line bg-surface p-5 shadow-card" aria-labelledby={`t-${s.id}`}>
          <h2 id={`t-${s.id}`} className="text-lg font-bold">{s.title}</h2><p className="mt-1 text-sm text-muted">{s.purpose}</p>
          <p className="mt-2 text-sm"><span className="font-semibold">Goals generated:</span> {iep.goals.length ? iep.goals.map((g) => g.areaLabel).join('; ') : 'none'}</p>
          <ul className="mt-3 space-y-1.5 text-sm">{checks.map((c) => <li key={c.label} className="flex items-start gap-2"><span className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${c.pass ? 'bg-ok-soft text-ok' : 'bg-danger-soft text-danger'}`}><Icon name={c.pass ? 'check' : 'x'} size={12} /></span><span><span className="font-semibold">{c.pass ? 'Pass' : 'Fail'}:</span> {c.label}</span></li>)}</ul>
          <div className="mt-3 flex flex-wrap gap-2"><Button small icon="file" onClick={() => onOpenIEP(iep)}>View generated IEP</Button><Button small icon="edit" onClick={() => onLoad(s.data)}>Load into form</Button></div>
        </section>))}
    </div>
  );
};
