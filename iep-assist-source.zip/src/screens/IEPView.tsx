import React, { useState } from 'react';
import { Goal, IEPDocument, NeedItem } from '../types';
import { Button, Callout, ConfirmationCheckbox, Icon, Modal, StatusBadge, Tag } from '../components/ui';
import { BulletList, EditableSection, EvidencePanel, GoalCard, IEPSection, LinesEditor, MissingInfoList, RecCards } from '../components/iep';
import { ProgressIndicator } from '../components/iep';
import { STEP_LABELS } from './Wizard';
import { DRAFT_NOTICE, REVIEW_PERIODS, SOURCES } from '../services/referenceData';
import { goalNeedsAttention } from '../services/goalQuality';
import { SectionKey } from '../services/iepGenerator';
import { fmt } from './Dashboard';
import { NO_GOAL_MESSAGE } from '../services/referenceData';

interface Props {
  iep: IEPDocument; onChange: (i: IEPDocument) => void; onSave: () => void; onApprove: () => void; onNew: () => void; onBack: () => void;
  onRegenerate: (k: SectionKey) => void; onCopy: () => void; onPrint: () => void; onAudit: (a: string, d: string) => void;
}

const TextIn: React.FC<{ label: string; value: string; onChange: (v: string) => void; area?: boolean }> = ({ label, value, onChange, area }) => (
  <label className="block text-sm"><span className="mb-1 block font-semibold">{label}</span>
    {area ? <textarea rows={2} value={value} onChange={(e) => onChange(e.target.value)} className="w-full rounded-lg border border-line bg-surface p-2.5" /> : <input value={value} onChange={(e) => onChange(e.target.value)} className="min-h-[40px] w-full rounded-lg border border-line bg-surface px-2.5" />}
  </label>
);

const Field: React.FC<{ label: string; children: React.ReactNode }> = ({ label, children }) => (<div><dt className="text-xs font-semibold uppercase tracking-wide text-muted">{label}</dt><dd className="mt-0.5 text-[15px] font-medium">{children}</dd></div>);

export const IEPView: React.FC<Props> = ({ iep, onChange, onSave, onApprove, onNew, onBack, onRegenerate, onCopy, onPrint }) => {
  const [editing, setEditing] = useState<Record<string, boolean>>({});
  const [modal, setModal] = useState<null | 'approve' | 'pdf' | 'new' | SectionKey>(null);
  const [ack, setAck] = useState(false);
  const allEdit = Object.values(editing).some(Boolean);
  const upd = (p: Partial<IEPDocument>) => onChange({ ...iep, ...p });
  const tog = (k: string) => setEditing({ ...editing, [k]: !editing[k] });
  const setAll = () => { const on = !allEdit; setEditing(Object.fromEntries(['profile', 'strengths', 'presentLevels', 'needs', 'goals', 'accommodations', 'strategies', 'monitoring'].map((k) => [k, on]))); };
  const L = iep.learner;
  const flagged = iep.goals.filter(goalNeedsAttention).length;
  const openMissing = iep.missing.filter((m) => !m.resolved && m.kind !== 'not_relevant').length;
  const setGoal = (g: Goal) => upd({ goals: iep.goals.map((x) => (x.id === g.id ? g : x)) });
  const setReview = (v: string) => upd({ reviewPeriod: v, goals: iep.goals.map((g) => (g.monitoring.reviewPoint === iep.reviewPeriod ? { ...g, monitoring: { ...g.monitoring, reviewPoint: v } } : g)) });
  const setNeed = (id: string, statement: string) => upd({ needs: iep.needs.map((n) => (n.id === id ? { ...n, statement } : n)) });

  return (
    <div className="space-y-5">
      <div className="no-print"><ProgressIndicator steps={STEP_LABELS} current={6} maxReached={7} /></div>
      <div className="no-print flex flex-wrap items-center justify-between gap-3">
        <div><div className="flex flex-wrap items-center gap-2"><h1 className="text-2xl font-bold sm:text-3xl">Individualised Education Plan</h1><StatusBadge status={iep.status} /></div><p className="text-sm text-muted">{iep.reference} · Updated {fmt(iep.updatedAt)}</p></div>
        <Button variant="ghost" icon="left" onClick={onBack}>Dashboard</Button>
      </div>
      <div className="print-only"><h1 className="text-2xl font-bold">Individualised Education Plan — {iep.reference} ({iep.status})</h1></div>

      <div className="card rounded-2xl border border-brand bg-brand-soft p-4" role="note">
        <p className="flex items-center gap-2 font-bold"><Icon name="info" /> AI-Generated Draft</p>
        <p className="mt-1 text-sm leading-relaxed">{DRAFT_NOTICE}</p>
      </div>

      <div className="no-print sticky z-20 flex flex-wrap items-center gap-2 rounded-2xl border border-line bg-surface p-3 shadow-card" style={{ top: 'calc(env(safe-area-inset-top, 0px) + 64px)' }}>
        <Button small variant={allEdit ? 'primary' : 'secondary'} icon="edit" onClick={setAll}>{allEdit ? 'Finish editing' : 'Edit IEP'}</Button>
        <Button small variant="primary" icon="save" onClick={onSave}>Save IEP</Button>
        <Button small icon="check" onClick={() => { setAck(false); setModal('approve'); }}>Approve as final</Button>
        <Button small icon="print" onClick={onPrint}>Print IEP</Button>
        <Button small icon="download" onClick={() => setModal('pdf')}>Export PDF</Button>
        <Button small icon="copy" onClick={onCopy}>Copy IEP</Button>
        <Button small variant="ghost" icon="plus" onClick={() => setModal('new')}>Start New IEP</Button>
        <p className="ml-auto flex flex-wrap gap-2 text-xs"><Tag tone="brand">{iep.goals.length} goal{iep.goals.length === 1 ? '' : 's'}</Tag><Tag tone={flagged ? 'warn' : 'ok'} icon={flagged ? 'alert' : 'check'}>{flagged} flagged for review</Tag><Tag tone={openMissing ? 'warn' : 'ok'} icon={openMissing ? 'alert' : 'check'}>{openMissing} missing-information item{openMissing === 1 ? '' : 's'}</Tag></p>
      </div>

      {iep.languageNotes.length > 0 && <Callout tone="warn" title="Wording that needs your attention">{iep.languageNotes.map((n) => <p key={n}>{n}</p>)}</Callout>}

      <EditableSection id="profile" number="1." title="Learner profile" editing={!!editing.profile} onToggle={() => tog('profile')} onRegenerate={() => setModal('profile')}
        view={<dl className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field label="Learner name">{L.learnerName}</Field><Field label="Grade/class">{L.grade}</Field><Field label="Age">{L.age} years</Field>
          <Field label="Date">{fmt(iep.iepDate)}</Field><Field label="IEP status">{iep.status}</Field>
          <div className="sm:col-span-2 lg:col-span-3"><dt className="text-xs font-semibold uppercase tracking-wide text-muted">Diagnosis / identified need</dt><dd className="mt-0.5 text-[15px] font-medium">{iep.diagnosisNote}</dd></div>
        </dl>}
        editor={<div className="grid gap-3 sm:grid-cols-2">
          <TextIn label="Learner name" value={L.learnerName} onChange={(v) => upd({ learner: { ...L, learnerName: v } })} />
          <TextIn label="Grade/class" value={L.grade} onChange={(v) => upd({ learner: { ...L, grade: v } })} />
          <TextIn label="Age" value={L.age} onChange={(v) => upd({ learner: { ...L, age: v } })} />
          <TextIn label="Date (YYYY-MM-DD)" value={iep.iepDate} onChange={(v) => upd({ iepDate: v })} />
          <div className="sm:col-span-2"><TextIn area label="Diagnosis / identified need note" value={iep.diagnosisNote} onChange={(v) => upd({ diagnosisNote: v })} /></div>
        </div>} />

      <EditableSection tone="gold" id="strengths" number="2." title="Learner strengths" intro="Strengths come first. The learner is viewed as a whole person with abilities, interests and potential." editing={!!editing.strengths} onToggle={() => tog('strengths')} onRegenerate={() => setModal('strengths')}
        view={iep.strengths.length ? <ul className="grid gap-2 sm:grid-cols-2">{iep.strengths.map((s, i) => <li key={i} className="flex gap-2 rounded-xl bg-ok-soft p-3 text-sm font-medium"><Icon name="star" size={16} className="mt-0.5 text-ok" />{s}</li>)}</ul> : <BulletList items={[]} />}
        editor={<LinesEditor label="Strengths (one per line)" value={iep.strengths} onChange={(v) => upd({ strengths: v })} />} />

      <EditableSection id="presentLevels" number="3." title="Present levels of academic and functional performance" intro="Organised around the evidence supplied by the teacher. Areas without evidence are not filled in." editing={!!editing.presentLevels} onToggle={() => tog('presentLevels')} onRegenerate={() => setModal('presentLevels')}
        view={<div className="space-y-4">{iep.presentLevels.map((p) => (
          <div key={p.domain} className="rounded-xl border border-line p-4">
            <h3 className="text-lg font-bold">{p.title}</h3><p className="text-sm font-semibold text-muted">{p.level}</p>
            {p.statusMessage && <p className="mt-2 rounded-lg bg-warn-soft p-2.5 text-sm">{p.statusMessage}</p>}
            <div className="mt-3 grid gap-4 md:grid-cols-2">
              <div><h4 className="mb-1 text-sm font-bold">Strengths</h4><BulletList items={p.strengths} empty="No strengths were described for this area." /></div>
              <div><h4 className="mb-1 text-sm font-bold">Documented needs</h4><BulletList items={p.needs} empty="No documented need." /></div>
              <div><h4 className="mb-1 text-sm font-bold">Observable information (teacher-reported)</h4><BulletList items={p.observations} empty="No observations recorded." /></div>
              <div><h4 className="mb-1 text-sm font-bold">Baseline information</h4><BulletList items={p.baseline} empty="[Baseline data required] No goal was set, so no baseline is needed yet." /></div>
            </div>
          </div>))}</div>}
        editor={<div className="space-y-4">{iep.presentLevels.map((p, i) => {
          const setP = (k: string, v: string | string[]) => upd({ presentLevels: iep.presentLevels.map((x, j) => (j === i ? { ...x, [k]: v } : x)) });
          return (<div key={p.domain} className="space-y-3 rounded-xl border border-line p-3"><h3 className="font-bold">{p.title}</h3>
            <TextIn label="Level" value={p.level} onChange={(v) => setP('level', v)} /><TextIn area label="Status note" value={p.statusMessage} onChange={(v) => setP('statusMessage', v)} />
            <LinesEditor label="Strengths (one per line)" value={p.strengths} onChange={(v) => setP('strengths', v)} /><LinesEditor label="Documented needs" value={p.needs} onChange={(v) => setP('needs', v)} />
            <LinesEditor label="Observable information" value={p.observations} onChange={(v) => setP('observations', v)} /><LinesEditor label="Baseline information" value={p.baseline} onChange={(v) => setP('baseline', v)} /></div>);
        })}</div>} />

      <EditableSection id="needs" number="4." title="Identified educational needs" intro="Only needs supported by the teacher’s information. Each need can be traced to its evidence." editing={!!editing.needs} onToggle={() => tog('needs')} onRegenerate={() => setModal('needs')}
        view={<div className="space-y-3">
          {iep.needs.length === 0 && <Callout>No educational needs were identified from the information supplied. This does not mean that none exist. It means that no learner-specific evidence was provided. See Missing information.</Callout>}
          {iep.needs.map((n: NeedItem) => (
            <div key={n.id} className="rounded-xl border border-line p-4">
              <div className="flex flex-wrap items-center gap-2"><p className="font-semibold">{n.statement}</p>
                <Tag tone={n.hasGoal ? 'ok' : 'neutral'}>{n.hasGoal ? 'Goal proposed' : 'No goal in this draft'}</Tag>
                {n.source === 'parent' && <Tag tone="warn">Parent/carer-reported</Tag>}
                {n.overlap !== 'n/a' && <Tag tone="brand">{n.overlap === 'overlapping' ? 'Overlapping need' : 'Distinct need'}</Tag>}</div>
              <p className="mt-1 text-sm text-muted">{n.note}</p>
              <EvidencePanel why={`Identified because of the information you supplied${n.source === 'parent' ? ' (parent/carer concerns)' : ''}.`} evidence={n.evidence} />
            </div>))}
          {iep.overlapSummary.length > 0 && <div className="rounded-xl bg-surface-2 p-4"><h3 className="mb-1 font-bold">Co-occurring needs: overlapping and distinct areas</h3><BulletList items={iep.overlapSummary} /></div>}
        </div>}
        editor={<div className="space-y-2">{iep.needs.map((n) => (<div key={n.id} className="flex gap-2"><div className="flex-1"><TextIn label="Need statement" value={n.statement} onChange={(v) => setNeed(n.id, v)} /></div><Button small variant="danger" icon="trash" className="mt-6" aria-label="Remove need" onClick={() => upd({ needs: iep.needs.filter((x) => x.id !== n.id) })} /></div>))}
          <Button small icon="plus" onClick={() => upd({ needs: [...iep.needs, { id: `add_${Date.now()}`, domain: 'reading', areaKey: 'custom', statement: 'Requires support with …', evidence: [], source: 'teacher', hasGoal: false, overlap: 'n/a', note: 'Added by the teacher.' }] })}>Add need</Button></div>} />

      <EditableSection tone="accent" id="goals" number="5." title="Measurable goals" intro="Goals are proposed only where the teacher’s evidence supports them. Each shows its condition, target skill, criterion, method of measurement and timeframe." editing={!!editing.goals} onToggle={() => tog('goals')} onRegenerate={() => setModal('goals')}
        view={<GoalsBlock iep={iep} editing={false} setGoal={setGoal} upd={upd} />} editor={<GoalsBlock iep={iep} editing setGoal={setGoal} upd={upd} />} />

      <EditableSection tone="accent" id="accommodations" number="6." title="Classroom accommodations" intro="Based on documented needs. The diagnosis alone never prescribes an accommodation." editing={!!editing.accommodations} onToggle={() => tog('accommodations')} onRegenerate={() => setModal('accommodations')}
        view={<RecCards items={iep.accommodations} editing={false} onChange={() => {}} empty="No accommodations were recommended because no documented need was identified. [Teacher observation recommended]" />}
        editor={<RecCards items={iep.accommodations} editing onChange={(r) => upd({ accommodations: r })} empty="" />} />

      <EditableSection tone="accent" id="strategies" number="7." title="Teacher strategies" intro="What the teacher can do in the classroom. Some build on the learner’s strengths." editing={!!editing.strategies} onToggle={() => tog('strategies')} onRegenerate={() => setModal('strategies')}
        view={<RecCards items={iep.strategies} editing={false} onChange={() => {}} empty="No strategies were recommended because no documented need was identified. [Teacher observation recommended]" />}
        editor={<RecCards items={iep.strategies} editing onChange={(r) => upd({ strategies: r })} empty="" />} />

      <EditableSection id="monitoring" number="8." title="Progress monitoring and review timeline" intro="A plan for every goal. No monitoring data is created by IEP Assist." editing={!!editing.monitoring} onToggle={() => tog('monitoring')} onRegenerate={() => setModal('monitoring')}
        view={<MonitoringBlock iep={iep} editing={false} upd={upd} setReview={setReview} />} editor={<MonitoringBlock iep={iep} editing upd={upd} setReview={setReview} />} />

      <IEPSection tone="warn" id="missing" number="9." title="Missing information" intro="Nothing is hidden. Items are grouped by why the information is absent. Tick “Resolved” once you have addressed an item.">
        <MissingInfoList items={iep.missing} onToggle={(id) => upd({ missing: iep.missing.map((m) => (m.id === id ? { ...m, resolved: !m.resolved } : m)) })} />
      </IEPSection>

      <IEPSection id="how" number="10." title="How this draft was produced" intro="A transparent record of the drafting pipeline and the reference frameworks used.">
        <ol className="space-y-2 text-sm">{iep.trace.map((t, i) => (<li key={t.step} className="flex gap-3"><span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-brand-soft text-xs font-bold text-brand-text">{i + 1}</span><span><span className="font-semibold">{t.step}.</span> {t.detail}</span></li>))}</ol>
        <div className="mt-5 rounded-xl bg-surface-2 p-4 text-sm"><h3 className="mb-1 font-bold">Source hierarchy</h3>
          <p className="mb-2 text-muted">Teacher data is the learner-specific evidence. Frameworks give structure. The AI synthesises and drafts. The teacher makes the final judgement. No organisation endorses this application.</p>
          <ol className="list-decimal space-y-1 pl-5">{SOURCES.map((s) => <li key={s.id}><span className="font-semibold">{s.name}</span> <Tag tone={s.verification === 'Verified' || s.verification === 'Primary evidence' ? 'ok' : 'warn'}>{s.verification}</Tag></li>)}</ol></div>
      </IEPSection>

      {modal === 'approve' && <Modal title="Approve this IEP as final?" onClose={() => setModal(null)} actions={<><Button onClick={() => setModal(null)}>Cancel</Button><Button variant="primary" disabled={!ack} onClick={() => { onApprove(); setModal(null); }}>Approve and save</Button></>}>
        <p className="mb-3">Approval marks the IEP as Completed. It does not make the AI content authoritative. You remain responsible for its accuracy.</p>
        {(flagged > 0 || openMissing > 0) && <Callout tone="warn" className="mb-3" title="Unresolved items">{flagged} goal(s) are flagged for review and {openMissing} missing-information item(s) are unresolved.</Callout>}
        <ConfirmationCheckbox id="ack" checked={ack} onChange={setAck}>I have reviewed and verified this IEP using assessment evidence and my professional judgement.</ConfirmationCheckbox></Modal>}
      {modal === 'pdf' && <Modal title="Export PDF (placeholder)" onClose={() => setModal(null)} actions={<><Button onClick={() => setModal(null)}>Close</Button><Button variant="primary" icon="print" onClick={() => { setModal(null); onPrint(); }}>Open print dialogue</Button></>}>
        <p>Direct PDF generation is not built into this prototype. It is planned for a later version. For now, open the print dialogue and choose “Save as PDF” as the destination.</p></Modal>}
      {modal === 'new' && <Modal title="Start a new IEP?" onClose={() => setModal(null)} actions={<><Button onClick={() => setModal(null)}>Cancel</Button><Button variant="primary" onClick={() => { setModal(null); onNew(); }}>Start new IEP</Button></>}><p>Unsaved changes to this IEP will be lost. Use Save IEP first if you want to keep them.</p></Modal>}
      {modal && !['approve', 'pdf', 'new'].includes(modal) && <Modal title="Regenerate this section?" onClose={() => setModal(null)} actions={<><Button onClick={() => setModal(null)}>Cancel</Button><Button variant="primary" icon="refresh" onClick={() => { onRegenerate(modal as SectionKey); setModal(null); }}>Regenerate section</Button></>}>
        <p>The section will be rebuilt from the original learner information. Any edits you made to this section will be replaced. Other sections are not changed.</p></Modal>}
    </div>
  );
};

const GoalsBlock: React.FC<{ iep: IEPDocument; editing: boolean; setGoal: (g: Goal) => void; upd: (p: Partial<IEPDocument>) => void }> = ({ iep, editing, setGoal, upd }) => (
  <div className="space-y-4">
    {iep.goals.length === 0 && <Callout tone="warn" title="No goals were generated">{NO_GOAL_MESSAGE} See the missing-information section for what would help.</Callout>}
    {iep.goals.map((g, i) => <GoalCard key={g.id} goal={g} index={i} editing={editing} onChange={setGoal} onRemove={() => upd({ goals: iep.goals.filter((x) => x.id !== g.id) })} />)}
    {iep.goals.length > 0 && iep.noGoalMessages.length > 0 && <div className="space-y-2">{iep.noGoalMessages.map((m) => <p key={m.domain} className="flex gap-2 rounded-xl bg-surface-2 p-3 text-sm"><Icon name="info" size={16} className="mt-0.5" />{m.message}</p>)}</div>}
    {iep.goals.length === 0 && iep.noGoalMessages.length > 0 && <div className="space-y-2">{iep.noGoalMessages.map((m) => <p key={m.domain} className="flex gap-2 rounded-xl bg-surface-2 p-3 text-sm"><Icon name="info" size={16} className="mt-0.5" />{m.message}</p>)}</div>}
  </div>
);

const MonitoringBlock: React.FC<{ iep: IEPDocument; editing: boolean; upd: (p: Partial<IEPDocument>) => void; setReview: (v: string) => void }> = ({ iep, editing, upd, setReview }) => {
  const setM = (id: string, k: string, v: string) => upd({ goals: iep.goals.map((g) => (g.id === id ? { ...g, monitoring: { ...g.monitoring, [k]: v } } : g)) });
  return (
    <div className="space-y-4">
      {iep.goals.length === 0 ? <p className="text-sm italic text-muted">No goals, so no goal-level monitoring is needed yet.</p> : iep.goals.map((g, i) => (
        <div key={g.id} className="rounded-xl border border-line p-4">
          <h3 className="mb-2 font-bold">Goal {i + 1}: {g.areaLabel}</h3>
          {editing ? <div className="grid gap-3 sm:grid-cols-2">{(['measure', 'method', 'frequency', 'collectedBy', 'reviewPoint'] as const).map((k) => <TextIn key={k} label={{ measure: 'What will be measured', method: 'How it will be measured', frequency: 'How often', collectedBy: 'Who collects the information', reviewPoint: 'When it is reviewed' }[k]} value={g.monitoring[k]} onChange={(v) => setM(g.id, k, v)} />)}</div>
            : <dl className="grid gap-3 text-sm sm:grid-cols-2 lg:grid-cols-5">{[['Measure', g.monitoring.measure], ['Method', g.monitoring.method], ['Frequency', g.monitoring.frequency], ['Collected by', g.monitoring.collectedBy], ['Review point', g.monitoring.reviewPoint]].map(([a, b]) => <div key={a}><dt className="font-semibold text-muted">{a}</dt><dd>{b}</dd></div>)}</dl>}
        </div>))}
      <div className="rounded-xl bg-surface-2 p-4">
        <label htmlFor="review" className="mb-1 block text-sm font-bold">Recommended review timeline</label>
        <select id="review" value={iep.reviewPeriod} onChange={(e) => setReview(e.target.value)} className="min-h-[44px] rounded-xl border border-line bg-surface px-3">
          {[...new Set([iep.reviewPeriod, ...REVIEW_PERIODS])].map((p) => <option key={p}>{p}</option>)}
        </select>
        <p className="mt-2 text-sm text-muted">This is a suggestion from IEP Assist. It is not a legal requirement. Adjust it to your school’s policy and the learner’s needs.</p>
      </div>
    </div>
  );
};
