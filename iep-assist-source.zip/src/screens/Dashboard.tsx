import React, { useMemo, useState } from 'react';
import { IEPDocument } from '../types';
import { Button, DashboardCard, EmptyState, FilterControl, SearchBar, StatusBadge } from '../components/ui';
import { GRADES } from '../services/referenceData';

export const initials = (n: string) => n.split(/\s+/).filter(Boolean).map((p) => p[0].toUpperCase()).join('.') + '.';
export const fmt = (iso: string) => new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });

const AVATARS = [['var(--brand)', '#fff'], ['var(--accent)', '#fff'], ['var(--gold)', '#0b1b34'], ['#c2410c', '#fff'], ['#7a45c9', '#fff']];
const avatar = (s: string) => AVATARS[[...s].reduce((a, c) => a + c.charCodeAt(0), 0) % AVATARS.length];

export const Dashboard: React.FC<{ records: IEPDocument[]; revealNames: boolean; userName: string; showHero: boolean; appName: string; onCreate: () => void; onTests: () => void; onOpen: (id: string) => void; onDelete: (id: string) => void }> = ({ records, revealNames, userName, showHero, appName, onCreate, onTests, onOpen, onDelete }) => {
  const [q, setQ] = useState('');
  const [status, setStatus] = useState('');
  const [grade, setGrade] = useState('');
  const week = Date.now() - 7 * 86400000;
  const shown = useMemo(() => records.filter((r) => {
    const hay = `${r.reference} ${r.learner.learnerName} ${initials(r.learner.learnerName)}`.toLowerCase();
    return (!q || hay.includes(q.toLowerCase())) && (!status || r.status === status) && (!grade || r.learner.grade === grade);
  }).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)), [records, q, status, grade]);
  return (
    <div className="space-y-6">
      {showHero ? (
        <section className="hero rounded-3xl p-6 shadow-card sm:p-9" aria-labelledby="dash-h">
          <p className="text-sm font-semibold uppercase tracking-widest" style={{ color: 'var(--gold)' }}>{appName}</p>
          <h1 id="dash-h" className="mt-1 text-3xl font-extrabold sm:text-4xl">Welcome back, <span className="capitalize">{userName}</span></h1>
          <p className="mt-2 max-w-xl text-white/85">Plan with evidence, not labels. Start a new IEP or review a draft. Learner names show as initials by default.</p>
          <div className="mt-5 flex flex-wrap gap-3"><Button variant="gold" icon="plus" onClick={onCreate}>Create New IEP</Button><Button variant="onDark" icon="flask" onClick={onTests}>See scenario tests</Button></div>
        </section>
      ) : (
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div><h1 className="text-2xl font-bold sm:text-3xl">Dashboard</h1><p className="text-sm text-muted">Learner names are shown as initials by default. All records are fictional.</p></div>
          <Button variant="primary" icon="plus" onClick={onCreate}>Create New IEP</Button>
        </div>
      )}
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <DashboardCard tone="navy" label="Total IEPs" value={records.length} icon="file" />
        <DashboardCard tone="gold" label="Draft IEPs" value={records.filter((r) => r.status === 'Draft').length} icon="edit" />
        <DashboardCard tone="teal" label="Completed IEPs" value={records.filter((r) => r.status === 'Completed').length} icon="check" />
        <DashboardCard tone="coral" label="Recently updated" value={records.filter((r) => new Date(r.updatedAt).getTime() > week).length} icon="refresh" hint="In the last 7 days" />
      </div>
      <section aria-labelledby="recent-h" className="space-y-3">
        <h2 id="recent-h" className="flex items-center gap-2 text-xl font-bold"><span className="inline-block h-6 w-1.5 rounded" style={{ background: 'var(--gold)' }} aria-hidden="true" />Recent IEPs</h2>
        <div className="grid gap-3 md:grid-cols-[1fr_180px_180px]">
          <SearchBar value={q} onChange={setQ} />
          <FilterControl id="f-status" label="Filter by status" value={status} onChange={setStatus} options={['Draft', 'Completed']} allLabel="All statuses" />
          <FilterControl id="f-grade" label="Filter by grade" value={grade} onChange={setGrade} options={GRADES} allLabel="All grades" />
        </div>
        {records.length === 0 ? <EmptyState title="No IEPs yet" text="Create your first IEP to see it here." action={<Button variant="primary" icon="plus" onClick={onCreate}>Create New IEP</Button>} />
          : shown.length === 0 ? <EmptyState title="No matching IEPs" text="Try a different search or clear the filters." action={<Button onClick={() => { setQ(''); setStatus(''); setGrade(''); }}>Clear search and filters</Button>} />
          : <ul className="space-y-2">{shown.map((r) => (
            <li key={r.id} className="card lift flex flex-wrap items-center gap-3 rounded-2xl border border-line bg-surface p-4 shadow-card" style={{ borderLeft: `5px solid ${avatar(r.learner.learnerName)[0]}` }}>
              <span className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full text-sm font-bold" style={{ background: avatar(r.learner.learnerName)[0], color: avatar(r.learner.learnerName)[1] }} aria-hidden="true">{initials(r.learner.learnerName).replace(/\./g, '').slice(0, 2)}</span>
              <div className="min-w-0 flex-1">
                <p className="font-semibold">{revealNames ? r.learner.learnerName : `Learner ${initials(r.learner.learnerName)}`} <span className="font-normal text-muted">· {r.reference}</span></p>
                <p className="text-sm text-muted">{r.learner.grade} · Updated {fmt(r.updatedAt)} · {r.goals.length} goal{r.goals.length === 1 ? '' : 's'}</p>
              </div>
              <StatusBadge status={r.status} />
              <div className="flex gap-2"><Button small onClick={() => onOpen(r.id)} icon="right">Open</Button><Button small variant="danger" icon="trash" onClick={() => onDelete(r.id)} aria-label={`Delete ${r.reference}`}><span className="sr-only">Delete</span></Button></div>
            </li>))}</ul>}
      </section>
    </div>
  );
};
