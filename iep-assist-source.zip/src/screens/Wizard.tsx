import React, { useEffect, useRef, useState } from 'react';
import { Condition, LearnerData, MULTIPLE } from '../types';
import { Button, Callout, ConfirmationCheckbox, InputField, MultiSelect, SelectField, TextAreaField } from '../components/ui';
import { ProgressIndicator, ReviewCard } from '../components/iep';
import { CONFIRMATION_TEXT, CONDITIONS, DIAGNOSIS_HELPER, DIAGNOSIS_LABELS, DIAGNOSIS_OPTIONS, GRADES, LEVELS } from '../services/referenceData';
import { FIELD_LABELS, languageFlags, softWarnings, validateAll, validateStep, Errors } from '../services/validation';
import { SCENARIOS } from '../services/scenarios';

export const STEP_LABELS = ['Learner', 'Academic', 'Behaviour', 'Strengths & Concerns', 'Review', 'Generate', 'IEP'];

const readingPrompts = ['decoding', 'phonological awareness', 'word recognition', 'reading fluency', 'spelling', 'reading comprehension', 'vocabulary', 'response to texts', 'reading confidence', 'strategies that have worked'];
const writingPrompts = ['handwriting and letter formation', 'copying', 'spelling in writing', 'written expression', 'organising written ideas', 'writing stamina', 'strategies that have worked'];
const mathPrompts = ['number sense', 'counting', 'quantity', 'number relationships', 'calculation', 'number facts', 'sequencing', 'reasoning', 'problem-solving', 'use of concrete materials', 'strategies that have worked'];
const behaviourPrompts = ['attention during tasks', 'task initiation', 'task completion', 'organisation', 'transitions', 'self-regulation', 'participation', 'peer interaction', 'communication', 'emotional regulation', 'response to instructions', 'successful classroom supports'];
const strengthPrompts = ['abilities', 'interests', 'talents', 'preferred learning approaches', 'successful strategies', 'areas of confidence', 'positive qualities', 'communication', 'social strengths', 'academic strengths', 'creativity', 'problem-solving'];

export const Wizard: React.FC<{ draft: LearnerData; setDraft: (d: LearnerData) => void; onGenerate: () => void; onCancel: () => void }> = ({ draft, setDraft, onGenerate, onCancel }) => {
  const [step, setStep] = useState(1);
  const [maxReached, setMax] = useState(0);
  const [errors, setErrors] = useState<Errors>({});
  const [confirmed, setConfirmed] = useState(false);
  const top = useRef<HTMLHeadingElement>(null);
  useEffect(() => { top.current?.focus(); window.scrollTo({ top: 0 }); }, [step]);
  const set = (p: Partial<LearnerData>) => setDraft({ ...draft, ...p });

  const go = (n: number) => { setErrors({}); setStep(n); setMax((m) => Math.max(m, n - 1)); };
  const next = () => {
    const e = validateStep(step, draft);
    setErrors(e);
    if (Object.keys(e).length) return;
    go(step + 1);
  };
  const jump = (idx: number) => {
    const target = idx + 1;
    if (target > step) { const e = validateStep(step, draft); setErrors(e); if (Object.keys(e).length) return; }
    setErrors({}); setStep(target);
  };
  const generate = () => {
    const { errors: e, firstStep } = validateAll(draft);
    if (firstStep) { setErrors(e); setStep(firstStep); return; }
    onGenerate();
  };

  const selected = [...(draft.coOccurring ? [MULTIPLE] : []), ...draft.diagnosis];
  const onDx = (v: string[]) => set({ coOccurring: v.includes(MULTIPLE), diagnosis: v.filter((x) => x !== MULTIPLE) as Condition[] });
  const flags = languageFlags(draft);
  const flagFor = (f: string) => { const x = flags.find((y) => y.field === f); return x ? (x.kind === 'deficit' ? `The wording “${x.term}” is deficit-based. Please describe what the learner does in neutral, observable terms. That statement will be left out of the generated draft.` : `“${x.term}” is a label rather than an observation. Please describe what you see the learner do. That statement will be left out of the generated draft.`) : undefined; };
  const errList = Object.values(errors);

  const readOnlyRows = (rows: [string, string][]) => rows.map(([label, value]) => ({ label, value }));

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 ref={top} tabIndex={-1} className="text-2xl font-bold focus:outline-none sm:text-3xl">Create New IEP</h1>
        <Button variant="ghost" onClick={onCancel}>Cancel</Button>
      </div>
      <ProgressIndicator steps={STEP_LABELS} current={step - 1} maxReached={maxReached} onGo={jump} />
      <p className="text-sm font-semibold text-muted" aria-live="polite">Step {step} of 6: {STEP_LABELS[step - 1]}</p>
      {errList.length > 0 && <Callout tone="danger" title="Please check the following before continuing"><ul className="list-disc pl-5">{errList.map((e) => <li key={e}>{e}</li>)}</ul></Callout>}

      <div className="card space-y-5 rounded-2xl border border-line bg-surface p-5 shadow-card sm:p-7" style={{ borderTop: '5px solid var(--accent)' }}>
        {step === 1 && (
          <>
            <h2 className="text-xl font-bold">Tell us about the learner</h2>
            <Callout title="Fictional data only">This prototype is for demonstration. Use invented learner details.</Callout>
            <div>
              <label htmlFor="scenario" className="mb-1.5 block text-sm font-semibold">Load a fictional test scenario <span className="ml-1 text-xs font-medium text-muted">Optional, for demonstration</span></label>
              <select id="scenario" className="min-h-[44px] w-full rounded-xl border border-line bg-surface px-3" value="" onChange={(e) => { const s = SCENARIOS.find((x) => x.id === e.target.value); if (s) { setDraft({ ...s.data }); setErrors({}); } }}>
                <option value="">Choose a scenario to pre-fill the form…</option>
                {SCENARIOS.map((s) => <option key={s.id} value={s.id}>{s.title}</option>)}
              </select>
            </div>
            <InputField id="learnerName" label="Name of Learner" required value={draft.learnerName} onChange={(e) => set({ learnerName: e.target.value })} error={errors.learnerName} autoComplete="off" maxLength={80} />
            <div className="grid gap-5 sm:grid-cols-2">
              <SelectField id="grade" label="Grade/Class" required value={draft.grade} onChange={(v) => set({ grade: v })} options={GRADES} error={errors.grade} />
              <InputField id="age" label="Age (years)" required inputMode="numeric" value={draft.age} onChange={(e) => set({ age: e.target.value.replace(/\D/g, '').slice(0, 2) })} error={errors.age} helper="Enter the learner’s age in whole years." />
            </div>
            <MultiSelect id="diagnosis" label="Diagnosis / Identified Need" required helper={DIAGNOSIS_HELPER} error={errors.diagnosis}
              options={DIAGNOSIS_OPTIONS.map((v) => ({ value: v, label: DIAGNOSIS_LABELS[v] }))} selected={selected} onChange={onDx} />
            {draft.coOccurring && <Callout title="Multiple/Co-occurring selected">Also select at least two of: {CONDITIONS.join(', ')}. The diagnosis is background context only. Needs and goals come from your observations.</Callout>}
          </>
        )}
        {step === 2 && (
          <>
            <h2 className="text-xl font-bold">Academic information</h2>
            <p className="text-sm text-muted">Only describe what you have observed or assessed. If you do not have the information, leave it blank or choose “Not Assessed”. The system will not fill gaps for you.</p>
            <section className="space-y-4" aria-labelledby="rd"><h3 id="rd" className="text-lg font-bold">Reading</h3>
              <SelectField id="readingLevel" label="Reading Level" required value={draft.readingLevel} onChange={(v) => set({ readingLevel: v as LearnerData['readingLevel'] })} options={LEVELS} error={errors.readingLevel} />
              <TextAreaField id="readingObservation" label="Reading Observation" optional value={draft.readingObservation} onChange={(v) => set({ readingObservation: v })} prompts={readingPrompts} warning={flagFor('readingObservation')} helper="Include any numbers you already have (for example, words read in a minute). Do not estimate." />
            </section>
            <section className="space-y-4" aria-labelledby="wr"><h3 id="wr" className="text-lg font-bold">Writing</h3>
              <TextAreaField id="writingObservation" label="Writing / Handwriting Observation" optional rows={5} value={draft.writingObservation} onChange={(v) => set({ writingObservation: v })} prompts={writingPrompts} warning={flagFor('writingObservation')} helper="Added so that writing evidence has a place. It has no level, because only observations are needed." />
            </section>
            <section className="space-y-4" aria-labelledby="mt"><h3 id="mt" className="text-lg font-bold">Mathematics</h3>
              <SelectField id="mathLevel" label="Mathematics Level" required value={draft.mathLevel} onChange={(v) => set({ mathLevel: v as LearnerData['mathLevel'] })} options={LEVELS} error={errors.mathLevel} />
              <TextAreaField id="mathObservation" label="Mathematics Observation" optional value={draft.mathObservation} onChange={(v) => set({ mathObservation: v })} prompts={mathPrompts} warning={flagFor('mathObservation')} />
            </section>
          </>
        )}
        {step === 3 && (
          <>
            <h2 className="text-xl font-bold">Behaviour / social-emotional</h2>
            <TextAreaField id="behaviourSocial" label="Behaviour / Social-Emotional" optional rows={8} value={draft.behaviourSocial} onChange={(v) => set({ behaviourSocial: v })} prompts={behaviourPrompts} warning={flagFor('behaviourSocial')}
              helper="Describe what you can observe (what the learner does, when, and what helps), not labels or assumptions. A diagnosis does not tell us how a learner behaves." />
          </>
        )}
        {step === 4 && (
          <>
            <h2 className="text-xl font-bold">Family concerns and strengths</h2>
            <TextAreaField id="parentConcerns" label="Parent/Carer Concerns" optional rows={5} value={draft.parentConcerns} onChange={(v) => set({ parentConcerns: v })} warning={flagFor('parentConcerns')}
              helper="Record concerns, priorities and goals the parent/carer shared with you. If there are none, leave this blank. The IEP will say they were not provided." />
            <TextAreaField id="learnerStrengths" label="Learner Strengths" required rows={7} value={draft.learnerStrengths} onChange={(v) => set({ learnerStrengths: v })} prompts={strengthPrompts} error={errors.learnerStrengths} warning={flagFor('learnerStrengths')}
              helper="Strengths come first in the IEP. Describe what the learner can do, enjoys and does well." />
          </>
        )}
        {step === 5 && (
          <>
            <h2 className="text-xl font-bold">Review the information</h2>
            <p className="text-sm text-muted">Check everything below. Use Edit to go back and change anything.</p>
            {softWarnings(draft).length > 0 && <Callout tone="warn" title="Things to be aware of"><ul className="list-disc pl-5">{softWarnings(draft).map((w) => <li key={w}>{w}</li>)}</ul></Callout>}
            {flags.length > 0 && <Callout tone="warn" title="Wording to review"><ul className="list-disc pl-5">{flags.map((f) => <li key={f.field + f.term}>{f.label}: “{f.term}” ({f.kind === 'deficit' ? 'deficit-based wording' : 'a label, not an observation'}). It will be left out of the draft.</li>)}</ul></Callout>}
            <div className="grid gap-4 md:grid-cols-2">
              <ReviewCard title="Learner" onEdit={() => go(1)} rows={readOnlyRows([['Name', draft.learnerName], ['Grade/Class', draft.grade], ['Age', draft.age ? `${draft.age} years` : ''], ['Diagnosis / Identified need (supplied by you)', draft.diagnosis.length ? (draft.coOccurring ? `Multiple/Co-occurring: ${draft.diagnosis.join(' + ')}` : draft.diagnosis.join(', ')) : '']])} />
              <ReviewCard title="Academic" onEdit={() => go(2)} rows={readOnlyRows([['Reading level', draft.readingLevel], [FIELD_LABELS.readingObservation, draft.readingObservation], [FIELD_LABELS.writingObservation, draft.writingObservation], ['Mathematics level', draft.mathLevel], [FIELD_LABELS.mathObservation, draft.mathObservation]])} />
              <ReviewCard title="Behaviour / Social-Emotional" onEdit={() => go(3)} rows={readOnlyRows([[FIELD_LABELS.behaviourSocial, draft.behaviourSocial]])} />
              <ReviewCard title="Strengths and concerns" onEdit={() => go(4)} rows={readOnlyRows([[FIELD_LABELS.learnerStrengths, draft.learnerStrengths], [FIELD_LABELS.parentConcerns, draft.parentConcerns]])} />
            </div>
          </>
        )}
        {step === 6 && (
          <>
            <h2 className="text-xl font-bold">Confirm and generate</h2>
            <p className="text-sm text-muted">IEP Assist will draft an IEP using only the information you entered. You will then review and edit every section.</p>
            <ol className="list-decimal space-y-1 pl-5 text-sm"><li>Your information is checked.</li><li>Strengths and documented needs are identified.</li><li>Goals are proposed only where your evidence supports them.</li><li>Accommodations, strategies and a monitoring plan are added, each with a reason.</li><li>You review, edit, save and approve.</li></ol>
            <ConfirmationCheckbox id="confirm" checked={confirmed} onChange={setConfirmed}>{CONFIRMATION_TEXT}</ConfirmationCheckbox>
            <Button variant="primary" icon="star" disabled={!confirmed} onClick={generate} aria-describedby="gen-hint">Generate IEP</Button>
            <p id="gen-hint" className="text-sm text-muted">{confirmed ? 'Ready to generate.' : 'Tick the confirmation to enable the Generate button.'}</p>
          </>
        )}
      </div>
      <div className="flex justify-between gap-3">
        <Button icon="left" disabled={step === 1} onClick={() => { setErrors({}); setStep(step - 1); }}>Back</Button>
        {step < 6 && <Button variant="primary" onClick={next}>{step === 5 ? 'Continue to confirmation' : 'Next'}<span aria-hidden="true">→</span></Button>}
      </div>
    </div>
  );
};
