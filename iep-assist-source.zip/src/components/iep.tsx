import React, { useState } from 'react';
import { EvidenceItem, Goal, MissingItem, Recommendation } from '../types';
import { checkGoal, formatGoal, isPending } from '../services/goalQuality';
import { Button, Callout, Icon, Tag } from './ui';

// ------------------------- Progress indicator -----------------------------
export const ProgressIndicator: React.FC<{ steps: string[]; current: number; maxReached: number; onGo?: (i: number) => void }> = ({ steps, current, maxReached, onGo }) => (
  <nav aria-label="Progress" className="no-print">
    <ol className="flex flex-wrap gap-x-1 gap-y-2 sm:flex-nowrap">
      {steps.map((s, i) => {
        const done = i < current || i < maxReached;
        const isCur = i === current;
        const canGo = !!onGo && i <= maxReached && !isCur;
        const inner = (
          <>
            <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-xs font-bold ${isCur ? 'bg-brand text-white' : done ? 'bg-ok text-bg' : 'border border-line bg-surface text-muted'}`}>
              {done && !isCur ? <Icon name="check" size={14} /> : i + 1}
            </span>
            <span className={`text-xs sm:text-[13px] ${isCur ? 'font-bold' : 'font-medium text-muted'}`}>{s}{isCur && <span className="sr-only"> (current step)</span>}{done && !isCur && <span className="sr-only"> (completed)</span>}</span>
          </>
        );
        return (
          <li key={s} className="flex min-w-0 flex-1 items-center" aria-current={isCur ? 'step' : undefined}>
            {canGo ? (
              <button type="button" onClick={() => onGo!(i)} className="flex items-center gap-2 rounded-lg p-1 text-left hover:bg-brand-soft">{inner}</button>
            ) : (
              <div className="flex items-center gap-2 p-1">{inner}</div>
            )}
            {i < steps.length - 1 && <span className="mx-1 hidden h-px flex-1 bg-line sm:block" aria-hidden="true" />}
          </li>
        );
      })}
    </ol>
  </nav>
);

// ------------------------------ Review card -------------------------------
export const ReviewCard: React.FC<{ title: string; onEdit?: () => void; rows: { label: string; value: string; required?: boolean }[] }> = ({ title, onEdit, rows }) => (
  <section className="card rounded-2xl border border-line bg-surface p-5 shadow-card" aria-label={title}>
    <div className="mb-3 flex items-center justify-between gap-3">
      <h3 className="text-base font-bold">{title}</h3>
      {onEdit && <Button small variant="ghost" icon="edit" onClick={onEdit} aria-label={`Edit ${title}`}>Edit</Button>}
    </div>
    <dl className="space-y-3 text-sm">
      {rows.map((r) => (
        <div key={r.label}>
          <dt className="font-semibold text-muted">{r.label}</dt>
          <dd className={`mt-0.5 whitespace-pre-wrap leading-relaxed ${r.value ? '' : 'italic text-muted'}`}>{r.value || '[Information not provided]'}</dd>
        </div>
      ))}
    </dl>
  </section>
);

// ------------------------------ Sections ----------------------------------
export type SectionTone = 'brand' | 'accent' | 'gold' | 'warn';
const TONE_VAR: Record<SectionTone, { c: string; fg: string }> = { brand: { c: 'var(--brand)', fg: '#fff' }, accent: { c: 'var(--accent)', fg: '#fff' }, gold: { c: 'var(--gold)', fg: '#0b1b34' }, warn: { c: '#c2570c', fg: '#fff' } };
export const IEPSection: React.FC<{ id: string; title: string; number?: string; intro?: string; actions?: React.ReactNode; tone?: SectionTone; children: React.ReactNode }> = ({ id, title, number, intro, actions, tone = 'brand', children }) => (
  <section id={id} aria-labelledby={`${id}-h`} className="card scroll-mt-24 rounded-2xl border border-line bg-surface p-5 shadow-card sm:p-6" style={{ borderLeft: `6px solid ${TONE_VAR[tone].c}` }}>
    <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
      <div>
        <h2 id={`${id}-h`} className="flex items-center gap-2.5 text-xl font-bold">{number && <span className="flex h-8 min-w-[2rem] items-center justify-center rounded-lg px-1.5 text-sm font-extrabold" style={{ background: TONE_VAR[tone].c, color: TONE_VAR[tone].fg }}>{number.replace('.', '')}</span>}{title}</h2>
        {intro && <p className="mt-1 max-w-3xl text-sm text-muted">{intro}</p>}
      </div>
      {actions && <div className="no-print flex flex-wrap gap-2">{actions}</div>}
    </div>
    {children}
  </section>
);

export const EditableSection: React.FC<{
  id: string; title: string; number?: string; intro?: string; tone?: SectionTone; editing: boolean; onToggle: () => void; onRegenerate?: () => void;
  view: React.ReactNode; editor: React.ReactNode;
}> = ({ id, title, number, intro, tone, editing, onToggle, onRegenerate, view, editor }) => (
  <IEPSection id={id} title={title} number={number} intro={intro} tone={tone} actions={
    <>
      <Button small variant={editing ? 'primary' : 'secondary'} icon={editing ? 'check' : 'edit'} onClick={onToggle} aria-label={`${editing ? 'Finish editing' : 'Edit section'}: ${title}`}>{editing ? 'Done' : 'Edit section'}</Button>
      {onRegenerate && <Button small variant="ghost" icon="refresh" onClick={onRegenerate} aria-label={`Regenerate section: ${title}`}>Regenerate</Button>}
    </>
  }>
    {editing ? <div className="rounded-xl border border-dashed border-brand p-4">{editor}</div> : view}
  </IEPSection>
);

// ------------------------- Evidence traceability --------------------------
export const EvidencePanel: React.FC<{ why: string; evidence: EvidenceItem[]; note?: string }> = ({ why, evidence, note }) => {
  const [open, setOpen] = useState(false);
  return (
    <div className="mt-3 rounded-xl bg-surface-2 p-3 text-sm">
      <button type="button" onClick={() => setOpen(!open)} aria-expanded={open} className="no-print flex w-full items-center gap-2 rounded-lg text-left font-semibold text-brand-text">
        <Icon name="bulb" size={16} /> Why was this recommended?
        <Icon name={open ? 'up' : 'down'} size={16} className="ml-auto" />
      </button>
      <p className="print-only font-semibold">Why was this recommended?</p>
      <div className={`evidence-body mt-2 space-y-2 leading-relaxed ${open ? '' : 'hidden'}`}>
        <p>{why}</p>
        {evidence.length > 0 && (
          <ul className="space-y-1.5">
            {evidence.map((e, i) => (
              <li key={i} className="rounded-lg border border-line bg-surface px-3 py-2"><span className="text-xs font-semibold uppercase tracking-wide text-muted">From: {e.fieldLabel}</span><br />“{e.text}”</li>
            ))}
          </ul>
        )}
        {note && <p className="text-muted">{note}</p>}
      </div>
    </div>
  );
};

// -------------------------------- Goal card -------------------------------
const DOMAIN_TAG: Record<string, string> = { reading: 'Reading', mathematics: 'Mathematics', writing: 'Writing', functional: 'Behaviour / functional' };

const Comp: React.FC<{ n: string; label: string; value: string }> = ({ n, label, value }) => (
  <div className="rounded-xl border border-line p-3">
    <p className="text-xs font-semibold uppercase tracking-wide text-muted">{n}. {label}</p>
    <p className={`mt-1 text-sm leading-relaxed ${isPending(value) ? 'text-warn font-medium' : ''}`}>{value}</p>
  </div>
);

export const GoalCard: React.FC<{ goal: Goal; index: number; editing: boolean; onChange: (g: Goal) => void; onRemove: () => void }> = ({ goal, index, editing, onChange, onRemove }) => {
  const [showChecks, setShowChecks] = useState(false);
  const checks = checkGoal(goal);
  const open = checks.filter((c) => !c.passed);
  const set = (k: keyof Goal, v: string) => onChange({ ...goal, [k]: v });
  const setM = (k: keyof Goal['monitoring'], v: string) => onChange({ ...goal, monitoring: { ...goal.monitoring, [k]: v } });
  const In: React.FC<{ label: string; k: keyof Goal; area?: boolean }> = ({ label, k, area }) => (
    <label className="block text-sm"><span className="mb-1 block font-semibold">{label}</span>
      {area ? <textarea rows={3} value={goal[k] as string} onChange={(e) => set(k, e.target.value)} className="w-full rounded-lg border border-line bg-surface p-2.5" />
        : <input value={goal[k] as string} onChange={(e) => set(k, e.target.value)} className="min-h-[40px] w-full rounded-lg border border-line bg-surface px-2.5" />}
    </label>
  );
  return (
    <article className="card rounded-2xl border border-line bg-surface p-5 shadow-card" style={{ borderTop: `5px solid var(--d-${goal.domain})` }} aria-label={`Goal ${index + 1}: ${goal.areaLabel}`}>
      <div className="mb-3 flex flex-wrap items-center gap-2">
        <h3 className="text-lg font-bold">Goal {index + 1}: {goal.areaLabel}</h3>
        <span className="inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-bold text-white" style={{ background: `var(--d-${goal.domain})`, color: '#fff' }}>{DOMAIN_TAG[goal.domain]}</span>
        {open.length > 0 ? <Tag tone="warn" icon="alert">Flagged for teacher review</Tag> : <Tag tone="ok" icon="check">All checks passed</Tag>}
        {editing && <Button small variant="danger" icon="trash" className="ml-auto" onClick={onRemove} aria-label={`Remove goal ${index + 1}`}>Remove</Button>}
      </div>
      {editing ? (
        <div className="grid gap-3 sm:grid-cols-2">
          <In label="1. Condition" k="condition" area /><In label="2. Target skill (observable behaviour)" k="skill" area />
          <In label="3. Performance criterion" k="criterion" area /><In label="5. Timeframe" k="timeframe" />
          <In label="Baseline" k="baseline" area />
          <label className="block text-sm"><span className="mb-1 block font-semibold">4. Method of measurement</span><textarea rows={3} value={goal.monitoring.method} onChange={(e) => setM('method', e.target.value)} className="w-full rounded-lg border border-line bg-surface p-2.5" /></label>
        </div>
      ) : (
        <>
          <p className="rounded-xl bg-brand-soft p-3.5 text-[15px] leading-relaxed">{formatGoal(goal)}</p>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <Comp n="1" label="Condition" value={goal.condition} />
            <Comp n="2" label="Target skill (observable)" value={goal.skill} />
            <Comp n="3" label="Performance criterion" value={goal.criterion} />
            <Comp n="4" label="Method of measurement" value={goal.monitoring.method} />
            <Comp n="5" label="Timeframe" value={goal.timeframe} />
            <Comp n="•" label="Baseline" value={goal.baseline} />
          </div>
        </>
      )}
      {goal.overlapNote && <p className="mt-3 flex gap-2 text-sm text-muted"><Icon name="info" size={16} className="mt-0.5" />{goal.overlapNote}</p>}
      <EvidencePanel why={goal.why} evidence={goal.evidence} />
      <div className="mt-3 no-print">
        <button type="button" onClick={() => setShowChecks(!showChecks)} aria-expanded={showChecks} className="flex items-center gap-2 rounded-lg text-sm font-semibold text-brand-text">
          <Icon name={showChecks ? 'up' : 'down'} size={16} /> Goal quality check ({checks.length - open.length} of {checks.length} met)
        </button>
        {showChecks && (
          <ul className="mt-2 space-y-1.5 text-sm">
            {checks.map((c) => (
              <li key={c.id} className="flex items-start gap-2">
                <span className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full ${c.passed ? 'bg-ok-soft text-ok' : 'bg-warn-soft text-warn'}`}><Icon name={c.passed ? 'check' : 'alert'} size={12} /></span>
                <span><span className="font-semibold">{c.label}:</span> <span className="sr-only">{c.passed ? 'met. ' : 'needs attention. '}</span><span className="text-muted">{c.note}</span></span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </article>
  );
};

// ---------------------------- Editors / lists -----------------------------
export const LinesEditor: React.FC<{ label: string; value: string[]; onChange: (v: string[]) => void; help?: string }> = ({ label, value, onChange, help }) => {
  const [text, setText] = useState(value.join('\n'));
  return (
    <label className="block text-sm">
      <span className="mb-1 block font-semibold">{label}</span>
      {help && <span className="mb-1 block text-muted">{help}</span>}
      <textarea rows={Math.max(3, value.length + 1)} value={text} onChange={(e) => { setText(e.target.value); onChange(e.target.value.split('\n').map((s) => s.trim()).filter(Boolean)); }} className="w-full rounded-lg border border-line bg-surface p-2.5 leading-relaxed" />
    </label>
  );
};

export const BulletList: React.FC<{ items: string[]; empty?: string }> = ({ items, empty }) =>
  items.length ? <ul className="prose-list list-disc space-y-1 pl-5 text-sm leading-relaxed">{items.map((s, i) => <li key={i}>{s}</li>)}</ul> : <p className="text-sm italic text-muted">{empty || '[Information not provided]'}</p>;

export const RecCards: React.FC<{ items: Recommendation[]; editing: boolean; onChange: (r: Recommendation[]) => void; empty: string }> = ({ items, editing, onChange, empty }) => {
  if (!editing) {
    return items.length ? (
      <ul className="space-y-3">
        {items.map((r) => (
          <li key={r.id} className="rounded-xl border border-line p-4">
            <p className="text-[15px] font-medium leading-relaxed">{r.text}</p>
            <EvidencePanel why={r.why} evidence={r.evidence} />
          </li>
        ))}
      </ul>
    ) : <p className="text-sm italic text-muted">{empty}</p>;
  }
  const upd = (id: string, k: 'text' | 'why', v: string) => onChange(items.map((r) => (r.id === id ? { ...r, [k]: v } : r)));
  return (
    <div className="space-y-3">
      {items.map((r, i) => (
        <div key={r.id} className="space-y-2 rounded-xl border border-line p-3">
          <label className="block text-sm"><span className="mb-1 block font-semibold">Item {i + 1}</span><textarea rows={2} value={r.text} onChange={(e) => upd(r.id, 'text', e.target.value)} className="w-full rounded-lg border border-line bg-surface p-2.5" /></label>
          <label className="block text-sm"><span className="mb-1 block font-semibold">Why was this recommended?</span><textarea rows={2} value={r.why} onChange={(e) => upd(r.id, 'why', e.target.value)} className="w-full rounded-lg border border-line bg-surface p-2.5" /></label>
          <Button small variant="danger" icon="trash" onClick={() => onChange(items.filter((x) => x.id !== r.id))}>Remove item {i + 1}</Button>
        </div>
      ))}
      <Button small icon="plus" onClick={() => onChange([...items, { id: `add_${Math.random().toString(36).slice(2, 7)}`, text: '', why: 'Added by the teacher.', evidence: [], areaLabels: ['Teacher addition'] }])}>Add item</Button>
    </div>
  );
};

// ------------------------- Missing information ----------------------------
const KIND: Record<MissingItem['kind'], { label: string; tone: 'warn' | 'danger' | 'brand' | 'neutral'; icon: string }> = {
  not_provided: { label: 'Information not provided', tone: 'warn', icon: 'alert' },
  baseline_required: { label: 'Baseline data required', tone: 'danger', icon: 'alert' },
  observation_recommended: { label: 'Teacher observation recommended', tone: 'brand', icon: 'info' },
  not_assessed: { label: 'Not assessed', tone: 'warn', icon: 'info' },
  not_relevant: { label: 'Not relevant to documented needs', tone: 'neutral', icon: 'check' },
};

export const MissingInfoList: React.FC<{ items: MissingItem[]; onToggle: (id: string) => void }> = ({ items, onToggle }) => {
  if (!items.length) return <Callout tone="ok">No missing information was identified.</Callout>;
  return (
    <ul className="space-y-2">
      {items.map((m) => (
        <li key={m.id} className={`flex flex-wrap items-start gap-3 rounded-xl border border-line p-3 ${m.resolved ? 'opacity-60' : ''}`}>
          <Tag tone={KIND[m.kind].tone} icon={KIND[m.kind].icon}>{KIND[m.kind].label}</Tag>
          <div className="min-w-0 flex-1 text-sm leading-relaxed"><span className="font-semibold">{m.area}.</span> {m.message}</div>
          <label className="no-print flex items-center gap-2 text-xs font-semibold"><input type="checkbox" checked={!!m.resolved} onChange={() => onToggle(m.id)} className="h-4 w-4 accent-[var(--brand)]" /> Resolved</label>
        </li>
      ))}
    </ul>
  );
};
