import React, { useEffect, useId, useRef, useState } from 'react';

// ------------------------------- Icons ------------------------------------
const PATHS: Record<string, string> = {
  check: 'M20 6 9 17l-5-5', x: 'M18 6 6 18M6 6l12 12', plus: 'M12 5v14M5 12h14',
  right: 'm9 18 6-6-6-6', left: 'm15 18-6-6 6-6', down: 'm6 9 6 6 6-6', up: 'm18 15-6-6-6 6',
  search: 'M11 19a8 8 0 1 0 0-16 8 8 0 0 0 0 16zM21 21l-4.3-4.3',
  alert: 'M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0zM12 9v4M12 17h.01',
  info: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM12 16v-4M12 8h.01',
  edit: 'M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z',
  print: 'M6 9V2h12v7M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2M6 14h12v8H6z',
  copy: 'M9 9h11v11H9zM5 15H4a1 1 0 0 1-1-1V4a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v1',
  download: 'M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3',
  trash: 'M3 6h18M8 6V4h8v2M19 6l-1 14H6L5 6', user: 'M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z',
  home: 'M3 10.5 12 3l9 7.5V21H3z', settings: 'M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6',
  help: 'M12 22a10 10 0 1 0 0-20 10 10 0 0 0 0 20zM9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01',
  flask: 'M9 3h6M10 3v6L4 20a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1l-6-11V3', lock: 'M5 11h14v10H5zM8 11V7a4 4 0 0 1 8 0v4',
  refresh: 'M21 12a9 9 0 1 1-3-6.7L21 8M21 3v5h-5', save: 'M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2zM17 21v-8H7v8M7 3v5h8',
  file: 'M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6', shield: 'M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z',
  logout: 'M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9',
  bulb: 'M9 18h6M10 22h4M12 2a7 7 0 0 0-4 12.7c.6.5 1 1.3 1 2.3h6c0-1 .4-1.8 1-2.3A7 7 0 0 0 12 2z',
  star: 'M12 2l3 6.9 7.4.6-5.6 4.9 1.7 7.3L12 17.8 5.5 21.7l1.7-7.3L1.6 9.5 9 8.9z',
};
export const Icon: React.FC<{ name: keyof typeof PATHS | string; size?: number; className?: string }> = ({ name, size = 18, className = '' }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden="true" focusable="false" className={`shrink-0 ${className}`}>
    <path d={PATHS[name] || PATHS.info} />
  </svg>
);

// ------------------------------- Buttons ----------------------------------
type BtnProps = React.ButtonHTMLAttributes<HTMLButtonElement> & { variant?: 'primary' | 'secondary' | 'ghost' | 'danger' | 'gold' | 'onDark'; icon?: string; small?: boolean };
export const Button: React.FC<BtnProps> = ({ variant = 'secondary', icon, small, children, className = '', ...rest }) => {
  const base = 'inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-colors disabled:opacity-50 disabled:cursor-not-allowed select-none';
  const size = small ? 'px-3 py-1.5 text-sm min-h-[36px]' : 'px-4 py-2.5 text-sm min-h-[44px]';
  const v = {
    primary: 'bg-brand text-white hover:opacity-90',
    secondary: 'bg-surface text-ink border border-line hover:bg-surface-2',
    ghost: 'text-brand-text hover:bg-brand-soft',
    danger: 'bg-surface text-danger border border-danger hover:bg-danger-soft',
    gold: 'bg-gold text-[#0b1b34] font-bold hover:opacity-90 shadow-card',
    onDark: 'border border-white/50 text-white hover:bg-white/15',
  }[variant];
  return (
    <button type="button" className={`${base} ${size} ${v} ${className}`} {...rest}>
      {icon && <Icon name={icon} size={16} />}
      {children}
    </button>
  );
};

// ---------------------------- Status / tags -------------------------------
export const StatusBadge: React.FC<{ status: 'Draft' | 'Completed' }> = ({ status }) => (
  <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ${status === 'Completed' ? 'bg-ok-soft text-ok' : 'bg-warn-soft text-warn'}`}>
    <Icon name={status === 'Completed' ? 'check' : 'edit'} size={12} />
    {status}
  </span>
);
export const Tag: React.FC<{ tone?: 'neutral' | 'brand' | 'ok' | 'warn' | 'danger'; icon?: string; children: React.ReactNode }> = ({ tone = 'neutral', icon, children }) => {
  const c = { neutral: 'bg-surface-2 text-muted', brand: 'bg-brand-soft text-brand-text', ok: 'bg-ok-soft text-ok', warn: 'bg-warn-soft text-warn', danger: 'bg-danger-soft text-danger' }[tone];
  return <span className={`inline-flex items-center gap-1 rounded-full px-2.5 py-0.5 text-xs font-semibold ${c}`}>{icon && <Icon name={icon} size={12} />}{children}</span>;
};

export const ValidationMessage: React.FC<{ id?: string; children?: React.ReactNode }> = ({ id, children }) =>
  children ? (
    <p id={id} role="alert" className="mt-1.5 flex items-start gap-1.5 text-sm font-medium text-danger">
      <Icon name="alert" size={16} className="mt-0.5" />
      <span>{children}</span>
    </p>
  ) : null;

export const Callout: React.FC<{ tone?: 'info' | 'warn' | 'ok' | 'danger'; title?: string; children: React.ReactNode; className?: string }> = ({ tone = 'info', title, children, className = '' }) => {
  const c = { info: 'bg-brand-soft text-ink border-brand', warn: 'bg-warn-soft text-ink border-warn', ok: 'bg-ok-soft text-ink border-ok', danger: 'bg-danger-soft text-ink border-danger' }[tone];
  const ic = { info: 'info', warn: 'alert', ok: 'check', danger: 'alert' }[tone];
  return (
    <div className={`flex gap-3 rounded-xl border-l-4 p-3.5 text-sm ${c} ${className}`}>
      <Icon name={ic} size={18} className="mt-0.5" />
      <div>{title && <p className="font-semibold">{title}</p>}<div className="leading-relaxed">{children}</div></div>
    </div>
  );
};

// ------------------------------- Fields -----------------------------------
interface FieldShell { id: string; label: string; required?: boolean; helper?: React.ReactNode; error?: string }
const Label: React.FC<{ id: string; label: string; required?: boolean; optional?: boolean }> = ({ id, label, required, optional }) => (
  <label htmlFor={id} className="mb-1.5 block text-sm font-semibold">
    {label}
    {required && <span className="ml-1 text-danger" aria-hidden="true">*</span>}
    {required && <span className="sr-only"> (required)</span>}
    {optional && <span className="ml-2 text-xs font-medium text-muted">Optional</span>}
  </label>
);
const fieldCls = (err?: string) => `w-full rounded-xl border bg-surface px-3.5 py-2.5 text-[15px] min-h-[44px] ${err ? 'border-danger' : 'border-line'} hover:border-brand focus:border-brand`;

export const InputField: React.FC<FieldShell & React.InputHTMLAttributes<HTMLInputElement>> = ({ id, label, required, helper, error, ...rest }) => (
  <div>
    <Label id={id} label={label} required={required} />
    <input id={id} required={false} aria-required={required} aria-invalid={!!error} aria-describedby={`${id}-h ${id}-e`} className={fieldCls(error)} {...rest} />
    {helper && <p id={`${id}-h`} className="mt-1.5 text-sm text-muted">{helper}</p>}
    <ValidationMessage id={`${id}-e`}>{error}</ValidationMessage>
  </div>
);

export const SelectField: React.FC<FieldShell & { value: string; onChange: (v: string) => void; options: string[]; placeholder?: string }> = ({ id, label, required, helper, error, value, onChange, options, placeholder = 'Choose…' }) => (
  <div>
    <Label id={id} label={label} required={required} />
    <select id={id} value={value} onChange={(e) => onChange(e.target.value)} aria-required={required} aria-invalid={!!error} aria-describedby={`${id}-h ${id}-e`} className={fieldCls(error)}>
      <option value="">{placeholder}</option>
      {options.map((o) => <option key={o} value={o}>{o}</option>)}
    </select>
    {helper && <p id={`${id}-h`} className="mt-1.5 text-sm text-muted">{helper}</p>}
    <ValidationMessage id={`${id}-e`}>{error}</ValidationMessage>
  </div>
);

export const TextAreaField: React.FC<FieldShell & { value: string; onChange: (v: string) => void; prompts?: string[]; rows?: number; optional?: boolean; maxLength?: number; warning?: string }> = ({ id, label, required, optional, helper, error, value, onChange, prompts, rows = 6, maxLength = 2000, warning }) => (
  <div>
    <Label id={id} label={label} required={required} optional={optional} />
    {helper && <p id={`${id}-h`} className="mb-2 text-sm text-muted">{helper}</p>}
    {prompts && (
      <div className="mb-2 rounded-xl bg-surface-2 p-3 text-sm">
        <p className="mb-1 font-semibold">You might describe (only what you know):</p>
        <ul className="flex flex-wrap gap-x-4 gap-y-1 text-muted">{prompts.map((p) => <li key={p} className="before:mr-1.5 before:content-['•']">{p}</li>)}</ul>
      </div>
    )}
    <textarea id={id} value={value} rows={rows} maxLength={maxLength} onChange={(e) => onChange(e.target.value)} aria-required={required} aria-invalid={!!error} aria-describedby={`${id}-h ${id}-e ${id}-c`} className={`${fieldCls(error)} leading-relaxed`} />
    <div className="mt-1 flex justify-between gap-3 text-xs text-muted"><span id={`${id}-c`}>{value.length} / {maxLength} characters</span></div>
    {warning && <Callout tone="warn" className="mt-2">{warning}</Callout>}
    <ValidationMessage id={`${id}-e`}>{error}</ValidationMessage>
  </div>
);

export const ConfirmationCheckbox: React.FC<{ id: string; checked: boolean; onChange: (v: boolean) => void; children: React.ReactNode }> = ({ id, checked, onChange, children }) => (
  <label htmlFor={id} className="flex cursor-pointer items-start gap-3 rounded-xl border border-line bg-surface p-4 hover:bg-surface-2">
    <input id={id} type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="mt-1 h-5 w-5 shrink-0 accent-[var(--brand)]" />
    <span className="text-sm font-medium leading-relaxed">{children}</span>
  </label>
);

// ---------------------- Searchable multi-select combobox ------------------
export const MultiSelect: React.FC<FieldShell & { options: { value: string; label: string }[]; selected: string[]; onChange: (v: string[]) => void; placeholder?: string }> = ({ id, label, required, helper, error, options, selected, onChange, placeholder = 'Search or choose…' }) => {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [active, setActive] = useState(0);
  const box = useRef<HTMLDivElement>(null);
  const filtered = options.filter((o) => o.label.toLowerCase().includes(q.toLowerCase()));
  useEffect(() => {
    const h = (e: MouseEvent) => { if (box.current && !box.current.contains(e.target as Node)) setOpen(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, []);
  const toggle = (v: string) => onChange(selected.includes(v) ? selected.filter((x) => x !== v) : [...selected, v]);
  const onKey = (e: React.KeyboardEvent) => {
    if (e.key === 'ArrowDown') { e.preventDefault(); setOpen(true); setActive((a) => Math.min(a + 1, filtered.length - 1)); }
    else if (e.key === 'ArrowUp') { e.preventDefault(); setActive((a) => Math.max(a - 1, 0)); }
    else if (e.key === 'Enter') { if (open && filtered[active]) { e.preventDefault(); toggle(filtered[active].value); } }
    else if (e.key === 'Escape') setOpen(false);
    else if (e.key === 'Backspace' && !q && selected.length) onChange(selected.slice(0, -1));
  };
  const labelOf = (v: string) => options.find((o) => o.value === v)?.label.split(' — ')[0].replace(' (select two or more)', '') || v;
  return (
    <div ref={box}>
      <Label id={id} label={label} required={required} />
      {helper && <p id={`${id}-h`} className="mb-2 text-sm text-muted">{helper}</p>}
      <div className={`rounded-xl border bg-surface p-2 ${error ? 'border-danger' : 'border-line'} focus-within:border-brand`}>
        {selected.length > 0 && (
          <ul className="mb-2 flex flex-wrap gap-1.5" aria-label="Selected">
            {selected.map((v) => (
              <li key={v} className="inline-flex items-center gap-1 rounded-full bg-brand-soft py-1 pl-3 pr-1 text-sm font-semibold text-brand-text">
                {labelOf(v)}
                <button type="button" onClick={() => toggle(v)} aria-label={`Remove ${labelOf(v)}`} className="rounded-full p-1 hover:bg-surface"><Icon name="x" size={14} /></button>
              </li>
            ))}
          </ul>
        )}
        <input id={id} role="combobox" aria-expanded={open} aria-controls={`${id}-list`} aria-autocomplete="list" aria-required={required} aria-invalid={!!error}
          aria-activedescendant={open && filtered[active] ? `${id}-opt-${active}` : undefined} aria-describedby={`${id}-h ${id}-e`}
          value={q} placeholder={placeholder} autoComplete="off" onChange={(e) => { setQ(e.target.value); setOpen(true); setActive(0); }}
          onFocus={() => setOpen(true)} onClick={() => setOpen(true)} onKeyDown={onKey}
          className="min-h-[40px] w-full bg-transparent px-2 py-1.5 text-[15px] focus:outline-none" style={{ outline: 'none' }} />
      </div>
      {open && (
        <ul id={`${id}-list`} role="listbox" aria-multiselectable="true" aria-label={label} className="mt-1 max-h-64 overflow-auto rounded-xl border border-line bg-surface p-1 shadow-card">
          {filtered.length === 0 && <li className="px-3 py-2 text-sm text-muted">No matching option.</li>}
          {filtered.map((o, i) => {
            const sel = selected.includes(o.value);
            return (
              <li key={o.value} id={`${id}-opt-${i}`} role="option" aria-selected={sel} onMouseDown={(e) => e.preventDefault()} onClick={() => toggle(o.value)} onMouseEnter={() => setActive(i)}
                className={`flex cursor-pointer items-center gap-2 rounded-lg px-3 py-2.5 text-sm ${i === active ? 'bg-brand-soft' : ''}`}>
                <span className={`flex h-5 w-5 items-center justify-center rounded border ${sel ? 'border-brand bg-brand text-white' : 'border-line'}`}>{sel && <Icon name="check" size={14} />}</span>
                <span className="font-medium">{o.label}</span>
              </li>
            );
          })}
        </ul>
      )}
      <ValidationMessage id={`${id}-e`}>{error}</ValidationMessage>
    </div>
  );
};

// -------------------------------- Modal -----------------------------------
export const Modal: React.FC<{ title: string; onClose: () => void; children: React.ReactNode; actions?: React.ReactNode; wide?: boolean }> = ({ title, onClose, children, actions, wide }) => {
  const ref = useRef<HTMLDivElement>(null);
  const tid = useId();
  useEffect(() => {
    const prev = document.activeElement as HTMLElement | null;
    ref.current?.focus();
    const key = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'Tab' && ref.current) {
        const f = ref.current.querySelectorAll<HTMLElement>('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener('keydown', key);
    return () => { document.removeEventListener('keydown', key); prev?.focus?.(); };
  }, [onClose]);
  return (
    <div className="no-print fixed inset-0 z-50 flex items-end justify-center bg-black/50 p-3 sm:items-center" onMouseDown={(e) => { if (e.target === e.currentTarget) onClose(); }}>
      <div ref={ref} role="dialog" aria-modal="true" aria-labelledby={tid} tabIndex={-1} className={`max-h-[90vh] w-full overflow-auto rounded-2xl bg-surface p-6 shadow-card ${wide ? 'max-w-3xl' : 'max-w-lg'}`}>
        <div className="mb-3 flex items-start justify-between gap-4">
          <h2 id={tid} className="text-xl font-bold">{title}</h2>
          <button type="button" onClick={onClose} aria-label="Close dialogue" className="rounded-lg p-1.5 hover:bg-surface-2"><Icon name="x" /></button>
        </div>
        <div className="text-sm leading-relaxed">{children}</div>
        {actions && <div className="mt-5 flex flex-wrap justify-end gap-2">{actions}</div>}
      </div>
    </div>
  );
};

// ------------------------------- Toasts -----------------------------------
export interface ToastMsg { id: number; text: string; tone: 'ok' | 'info' | 'warn' }
export const ToastRegion: React.FC<{ toasts: ToastMsg[] }> = ({ toasts }) => (
  <div role="status" aria-live="polite" className="no-print pointer-events-none fixed bottom-4 left-1/2 z-[60] flex w-[min(92vw,28rem)] -translate-x-1/2 flex-col gap-2" style={{ bottom: 'calc(1rem + env(safe-area-inset-bottom, 0px))' }}>
    {toasts.map((t) => (
      <div key={t.id} className="pointer-events-auto flex items-center gap-2 rounded-xl bg-ink px-4 py-3 text-sm font-semibold text-bg shadow-card">
        <Icon name={t.tone === 'warn' ? 'alert' : t.tone === 'ok' ? 'check' : 'info'} size={16} />{t.text}
      </div>
    ))}
  </div>
);

// ---------------------------- Loading / empty -----------------------------
export const LoadingState: React.FC<{ title: string; steps: string[]; current: number }> = ({ title, steps, current }) => (
  <div className="mx-auto max-w-xl rounded-2xl border border-line bg-surface p-8 shadow-card card" role="status" aria-live="polite">
    <div className="mb-5 flex items-center gap-3">
      <span className="spin text-brand-text"><Icon name="refresh" size={26} /></span>
      <h2 className="text-xl font-bold">{title}</h2>
    </div>
    <ol className="space-y-2 text-sm">
      {steps.map((s, i) => (
        <li key={s} className={`flex items-center gap-2 ${i > current ? 'text-muted' : ''} ${i === current ? 'font-semibold' : ''}`}>
          <span className={`flex h-5 w-5 items-center justify-center rounded-full text-xs ${i < current ? 'bg-ok text-bg' : i === current ? 'bg-brand text-white' : 'bg-surface-2'}`}>{i < current ? <Icon name="check" size={12} /> : i + 1}</span>
          {s}{i === current && <span className="sr-only"> (in progress)</span>}
        </li>
      ))}
    </ol>
    <p className="mt-5 text-xs text-muted">This prototype uses a local rule-based simulation of AI drafting. Nothing is sent to an external service.</p>
  </div>
);

export const EmptyState: React.FC<{ title: string; text: string; action?: React.ReactNode }> = ({ title, text, action }) => (
  <div className="rounded-2xl border border-dashed border-line bg-surface p-10 text-center">
    <div className="mx-auto mb-3 flex h-12 w-12 items-center justify-center rounded-full bg-brand-soft text-brand-text"><Icon name="file" size={22} /></div>
    <h3 className="text-lg font-bold">{title}</h3>
    <p className="mx-auto mt-1 max-w-md text-sm text-muted">{text}</p>
    {action && <div className="mt-4">{action}</div>}
  </div>
);

const TONES: Record<string, { bg: string; fg: string }> = {
  navy: { bg: 'var(--brand)', fg: '#fff' }, gold: { bg: 'var(--gold)', fg: '#0b1b34' }, teal: { bg: 'var(--accent)', fg: '#fff' }, coral: { bg: '#c2410c', fg: '#fff' },
};
export const DashboardCard: React.FC<{ label: string; value: number | string; icon: string; hint?: string; tone?: keyof typeof TONES }> = ({ label, value, icon, hint, tone = 'navy' }) => (
  <div className="card lift overflow-hidden rounded-2xl border border-line bg-surface p-5 shadow-card" style={{ borderTop: `4px solid ${TONES[tone].bg}` }}>
    <div className="flex items-center justify-between"><span className="text-sm font-semibold text-muted">{label}</span>
      <span className="flex h-10 w-10 items-center justify-center rounded-xl" style={{ background: TONES[tone].bg, color: TONES[tone].fg }}><Icon name={icon} size={20} /></span></div>
    <p className="mt-2 text-4xl font-extrabold tracking-tight">{value}</p>
    {hint && <p className="mt-1 text-xs text-muted">{hint}</p>}
  </div>
);

export const SearchBar: React.FC<{ value: string; onChange: (v: string) => void; label?: string }> = ({ value, onChange, label = 'Search IEPs' }) => (
  <div className="relative">
    <label htmlFor="iep-search" className="sr-only">{label}</label>
    <Icon name="search" className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-muted" />
    <input id="iep-search" type="search" value={value} onChange={(e) => onChange(e.target.value)} placeholder="Search by reference, name or initials" className="min-h-[44px] w-full rounded-xl border border-line bg-surface py-2.5 pl-10 pr-3 text-[15px] hover:border-brand" />
  </div>
);

export const FilterControl: React.FC<{ id: string; label: string; value: string; onChange: (v: string) => void; options: string[]; allLabel: string }> = ({ id, label, value, onChange, options, allLabel }) => (
  <div>
    <label htmlFor={id} className="sr-only">{label}</label>
    <select id={id} value={value} onChange={(e) => onChange(e.target.value)} className="min-h-[44px] w-full rounded-xl border border-line bg-surface px-3 py-2.5 text-[15px] hover:border-brand">
      <option value="">{allLabel}</option>
      {options.map((o) => <option key={o} value={o}>{o}</option>)}
    </select>
  </div>
);

export const Logo: React.FC<{ size?: number }> = ({ size = 36 }) => (
  <span className="flex items-center justify-center rounded-xl shadow-card" style={{ width: size, height: size, background: 'var(--gold)', color: '#0b1b34' }} aria-hidden="true">
    <Icon name="file" size={size * 0.55} />
  </span>
);
