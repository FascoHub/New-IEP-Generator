import React, { useCallback, useEffect, useRef, useState } from 'react';
import { AppSettings, AuditEvent, IEPDocument, LearnerData } from './types';
import { Button, Icon, LoadingState, Logo, Modal, ToastMsg, ToastRegion } from './components/ui';
import { Login } from './screens/Login';
import { Dashboard } from './screens/Dashboard';
import { Wizard } from './screens/Wizard';
import { IEPView } from './screens/IEPView';
import { Help, ScenarioTests, Settings } from './screens/Info';
import { generateIEP, mockGeneratorService, regenerateSection, SectionKey } from './services/iepGenerator';
import { emptyLearner } from './services/validation';
import { APP_SUBTITLE, PIPELINE_LABELS } from './services/referenceData';
import { clearAll, loadAudit, loadRecords, loadSession, loadSettings, saveAudit, saveRecords, saveSession, saveSettings, seedRecords } from './services/storage';
import { iepToText } from './services/exportText';

type View = 'dashboard' | 'wizard' | 'generating' | 'iep' | 'tests' | 'help' | 'settings';

export const App: React.FC = () => {
  const [session, setSession] = useState(loadSession);
  const [records, setRecords] = useState<IEPDocument[]>(() => loadRecords() ?? seedRecords());
  const [audit, setAudit] = useState<AuditEvent[]>(loadAudit);
  const [settings, setSettings] = useState<AppSettings>(loadSettings);
  const [view, setView] = useState<View>('dashboard');
  const [draft, setDraft] = useState<LearnerData>(emptyLearner());
  const [current, setCurrent] = useState<IEPDocument | null>(null);
  const [dirty, setDirty] = useState(false);
  const [genStep, setGenStep] = useState(0);
  const [toasts, setToasts] = useState<ToastMsg[]>([]);
  const [confirmDel, setConfirmDel] = useState<string | null>(null);
  const [leave, setLeave] = useState<null | (() => void)>(null);
  const main = useRef<HTMLElement>(null);

  useEffect(() => { saveRecords(records); }, [records]);
  useEffect(() => { saveAudit(audit); }, [audit]);
  useEffect(() => {
    saveSettings(settings);
    const r = document.documentElement.style;
    r.setProperty('--brand', settings.theme.primary); r.setProperty('--accent', settings.theme.accent); r.setProperty('--gold', settings.theme.gold);
    const dark = window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
    if (dark) r.removeProperty('--brand-text'); else r.setProperty('--brand-text', settings.theme.primary);
    r.fontSize = settings.textSize === 'large' ? '112.5%' : '';
  }, [settings]);
  useEffect(() => { main.current?.focus({ preventScroll: true }); window.scrollTo({ top: 0 }); }, [view]);

  const toast = useCallback((text: string, tone: ToastMsg['tone'] = 'ok') => {
    const id = Date.now() + Math.random();
    setToasts((t) => [...t, { id, text, tone }]);
    setTimeout(() => setToasts((t) => t.filter((x) => x.id !== id)), 3200);
  }, []);
  const log = useCallback((action: string, detail: string) => setAudit((a) => [{ ts: new Date().toISOString(), action, detail }, ...a]), []);

  const guard = (fn: () => void) => { if (view === 'iep' && dirty) setLeave(() => fn); else fn(); };
  const nav = (v: View) => guard(() => { setView(v); });

  const startWizard = (d?: LearnerData) => guard(() => { setDraft(d ? { ...d } : emptyLearner()); setView('wizard'); log('Started IEP', 'Opened the new IEP form'); });

  const runGenerate = async () => {
    setView('generating'); setGenStep(0);
    const timer = setInterval(() => setGenStep((s) => Math.min(s + 1, PIPELINE_LABELS.length - 1)), 250);
    const seq = records.length + 1;
    const iep = await mockGeneratorService.generate(draft, { sequence: seq, reviewPeriod: settings.defaultReviewPeriod });
    clearInterval(timer);
    setCurrent(iep); setDirty(true); setView('iep'); log('Generated IEP', `${iep.reference} draft created (${iep.goals.length} goals)`);
  };

  const onChange = (i: IEPDocument) => { setCurrent({ ...i, updatedAt: new Date().toISOString(), status: i.status === 'Completed' ? 'Draft' : i.status }); setDirty(true); };
  const persist = (i: IEPDocument) => setRecords((rs) => (rs.some((r) => r.id === i.id) ? rs.map((r) => (r.id === i.id ? i : r)) : [i, ...rs]));
  const save = () => { if (!current) return; const c = { ...current, updatedAt: new Date().toISOString() }; setCurrent(c); persist(c); setDirty(false); log('Saved IEP', c.reference); toast('IEP saved'); };
  const approve = () => { if (!current) return; const c: IEPDocument = { ...current, status: 'Completed', updatedAt: new Date().toISOString() }; setCurrent(c); persist(c); setDirty(false); log('Approved IEP', `${c.reference} marked Completed`); toast('IEP approved and saved'); };
  const open = (id: string) => { const r = records.find((x) => x.id === id); if (r) { setCurrent(r); setDirty(false); setView('iep'); log('Viewed IEP', r.reference); } };
  const copy = async () => {
    if (!current) return; const text = iepToText(current);
    try { await navigator.clipboard.writeText(text); toast('IEP copied to clipboard'); log('Copied IEP', current.reference); }
    catch { try { const ta = document.createElement('textarea'); ta.value = text; document.body.appendChild(ta); ta.select(); document.execCommand('copy'); ta.remove(); toast('IEP copied to clipboard'); } catch { toast('Copy is not available in this browser', 'warn'); } }
  };
  const print = () => { log('Printed/exported IEP', current?.reference || ''); try { window.print(); } catch { toast('Printing is not available here', 'warn'); } };

  if (!session) return <><a className="skip-link" href="#main">Skip to main content</a><Login appName={settings.appName} onLogin={(name, role) => { const s = { name, role }; saveSession(s); setSession(s); log('Signed in', `${role} (demonstration)`); }} /></>;

  const NavBtn: React.FC<{ v: View; icon: string; label: string }> = ({ v, icon, label }) => (
    <button type="button" onClick={() => nav(v)} aria-current={view === v ? 'page' : undefined} className={`flex min-h-[44px] items-center gap-2 whitespace-nowrap rounded-xl px-3 text-sm font-semibold ${view === v ? 'bg-white/20 text-white' : 'text-white/80 hover:bg-white/10'}`} style={view === v ? { boxShadow: 'inset 0 -3px 0 var(--gold)' } : undefined}><Icon name={icon} size={16} />{label}</button>
  );

  return (
    <>
      <a className="skip-link" href="#main">Skip to main content</a>
      <header className="app-header no-print sticky z-30" style={{ top: 'env(safe-area-inset-top, 0px)' }}>
        <div className="mx-auto flex max-w-6xl flex-wrap items-center gap-x-4 gap-y-1 px-4 py-2.5">
          <button type="button" onClick={() => nav('dashboard')} className="flex items-center gap-3 rounded-lg text-left" aria-label={`${settings.appName}, go to dashboard`}><Logo /><span><span className="block text-lg font-extrabold leading-tight">{settings.appName}</span><span className="hidden text-xs text-white/80 sm:block">{APP_SUBTITLE}</span></span></button>
          <nav aria-label="Main" className="ml-auto flex max-w-full gap-1 overflow-x-auto">
            <NavBtn v="dashboard" icon="home" label="Dashboard" /><NavBtn v="tests" icon="flask" label="Scenario tests" /><NavBtn v="help" icon="help" label="Help" /><NavBtn v="settings" icon="settings" label="Settings" />
            <button type="button" onClick={() => guard(() => { saveSession(null); setSession(null); log('Signed out', ''); })} className="flex min-h-[44px] items-center gap-2 whitespace-nowrap rounded-xl px-3 text-sm font-semibold text-white/80 hover:bg-white/10"><Icon name="logout" size={16} />Sign out</button>
          </nav>
        </div>
      </header>
      <main id="main" ref={main} tabIndex={-1} className="mx-auto max-w-6xl px-4 py-6 focus:outline-none sm:py-8">
        {view === 'dashboard' && <Dashboard records={records} revealNames={settings.revealNames} userName={session.name.split(' ')[0]} showHero={settings.showHero} appName={settings.appName} onCreate={() => startWizard()} onTests={() => nav('tests')} onOpen={open} onDelete={setConfirmDel} />}
        {view === 'wizard' && <Wizard draft={draft} setDraft={setDraft} onGenerate={runGenerate} onCancel={() => setView('dashboard')} />}
        {view === 'generating' && <div className="py-8"><LoadingState title="Drafting the IEP from your information" steps={PIPELINE_LABELS} current={genStep} /></div>}
        {view === 'iep' && current && <IEPView iep={current} onChange={onChange} onSave={save} onApprove={approve} onNew={() => { setDirty(false); startWizard(); }} onBack={() => nav('dashboard')}
          onRegenerate={(k: SectionKey) => { setCurrent(regenerateSection(current, k)); setDirty(true); log('Regenerated section', `${current.reference}: ${k}`); toast('Section regenerated'); }} onCopy={copy} onPrint={print} onAudit={log} />}
        {view === 'tests' && <ScenarioTests onLoad={(d) => startWizard(d)} onOpenIEP={(i) => { setCurrent({ ...i, reference: 'TEST-SCENARIO' }); setDirty(false); setView('iep'); }} />}
        {view === 'help' && <Help />}
        {view === 'settings' && <Settings settings={settings} onSettings={setSettings} audit={audit} onDeleteAll={() => { clearAll(); setRecords([]); setAudit([]); setSettings(loadSettings()); toast('All saved records deleted'); }} />}
      </main>
      <footer className="no-print mx-auto max-w-6xl px-4 pb-8 text-xs text-muted">Research prototype. Fictional data only. AI-assisted drafting simulated locally. Not legal advice and not a diagnostic tool. No claim of legal compliance or organisational endorsement.</footer>
      {confirmDel && <Modal title="Delete this IEP?" onClose={() => setConfirmDel(null)} actions={<><Button onClick={() => setConfirmDel(null)}>Cancel</Button><Button variant="danger" icon="trash" onClick={() => { const r = records.find((x) => x.id === confirmDel); setRecords((rs) => rs.filter((x) => x.id !== confirmDel)); log('Deleted IEP', r?.reference || ''); setConfirmDel(null); toast('IEP deleted'); }}>Delete</Button></>}><p>This permanently removes the record from this browser.</p></Modal>}
      {leave && <Modal title="Leave without saving?" onClose={() => setLeave(null)} actions={<><Button onClick={() => setLeave(null)}>Stay</Button><Button variant="primary" onClick={() => { const f = leave; setLeave(null); setDirty(false); f(); }}>Leave without saving</Button></>}><p>This IEP has changes that have not been saved.</p></Modal>}
      <ToastRegion toasts={toasts} />
    </>
  );
};
